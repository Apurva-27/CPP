/*
5. Write a program which accept one number from user and range of
positions from user. Toggle all bits from that range.
Input : 897 9 13
Toggle all bits from position 9 to 13 of input number ie 879. 
*/

#include<stdio.h>

int Toggle(int iNo)
{
    int iMask=0x00001F00;
    int iResult=0;

    iResult = iNo ^ iMask;

    return iResult; 
}

int main()
{
    int iNO=0 , iRet=0;

    printf("Enter Number:\t");
    scanf("%d",&iNO);

    iRet = Toggle(iNO);

    printf("Number aft toggle\t%d",iRet);

    return 0; 
}