/*
4. Write a program which accept one number , two positions from user and
check whether bit at first or bit at second position is ON or OFF.
Input : 10 3 7
Output : TRUE 
*/

#include<stdio.h>
typedef int BOOL;

#define TRUE 1
#define FALSE 0

BOOL ChkBit(int iNo,int iPos1,int iPos2)
{
	int iResult=0;
	
	iResult= iPos1 + iPos2;
	
	if(iNo==iResult)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

int main()
{
	int iNo=0, iPos1=0, iPos2=0;
	BOOL bRet=FALSE;
	
	printf("Enter No");
	scanf("%d",&iNo);
	
	printf("Enter first position");
	scanf("%d",&iPos1);

	printf("Enter second position");
	scanf("%d",&iPos2);
	
	bRet = ChkBit(iNo,iPos1,iPos2);
	
	if(bRet==TRUE)
	{
		printf("Bit is on");
	}
	else
	{
		printf("Bit is off");
	}
	
	return 0;
}
