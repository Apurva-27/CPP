/*
1.Write a program which accept one number from user and count number of
ON (1) bits in it without using % and / operator.
Input : 11
Output : 3 
*/

#include<stdio.h>

int ChkOne(int iNo)
{
	int iMask=0x00000000;
	int iResult=0, iCnt=0;
	
	while(iNo)
	{
		iResult += iNo & 1;
			
		iNo>>=1;
	}
	
	return iResult;
	
	
	/*iResult= iNo | iMask;
	if(iResult==1)
	{iCnt++;}
	return iCnt;
*/
}

int main()
{
	int iNo=0, iRet=0;
	
	printf("Enter Number:\t");
	scanf("%d",&iNo);
	
	iRet=ChkOne(iNo);
	
	printf("Number of ones are: %d",iRet);
	
	return 0;
}