/*
3. Write a program which accept one number from user and check whether
9th or 12th bit is on or off.
Input : 257
Output : TRUE
*/

#include<stdio.h>
typedef int BOOL;

#define TRUE 1
#define FALSE 0

BOOL ChkBit(int iNo)
{
	int iMask=0x00000900;
	int iResult=0;
	
	iResult = iNo & iMask;
	
	if(iResult == iMask)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

int main()
{
	int iNo=0;
	BOOL bRet=FALSE;
	
	printf("Enter number\t");
	scanf("%d",&iNo);
	
	bRet= ChkBit(iNo);
	
	if(bRet==TRUE)
	{	
		printf("Bit is on");
	}
	else
	{
		printf("Bit is on");
	}
	
	return 0;
} 