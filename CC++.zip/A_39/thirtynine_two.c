/*
2. Write a program which search last occurrence of particular element from
singly linear linked list.
Function should return position at which element is found.
Function Prototype :int SearchLastOcc( PNODE Head, int no );
Input linked list : |10|->|20|->|30|->|40|->|50|->|30|->|70|
Input element : 30
Output : 6
*/

#include<stdio.h>
#include<stdlib.h> 

#define TRUE 1
#define FALSE 0

typedef int BOOL;

struct Node
{
 int Data;
 struct Node *Next;
};

typedef struct Node NODE;
typedef struct Node *PNODE;
typedef struct Node **PPNODE;

void InsertFirst(PPNODE Head, int no )
{
	PNODE newn = NULL;
	newn = (PNODE)malloc(sizeof(NODE));

	newn->Next = NULL;
	newn->Data = no;
	
	if (*Head == NULL)
	{
		*Head = newn;
	}
	else
	{
		newn -> Next = *Head;
		*Head = newn;
	}
}
void Diaplay(PNODE Head)
{
	while(Head!=NULL)
	{
		printf("%d\t",Head->Data);
		Head=Head->Next;
	}
}
int SearchLastOcc(PPNODE Head, int no )
{
	int iCnt=0;
	PNODE current=*Head;
	//PNODE prev=NULL;
	//PNODE temp=NULL;
	
	int temp=0;
	
	for(current=*Head; current->Next!=NULL; current=current->Next)
	{
		
		if(current->Data==no)
		{
			iCnt++;
		}
		else
		{
			iCnt++;
		}
	}
	
	/*while(current!=NULL)
	{
		if(current->data==no)
		{
			iCnt++;
			temp =iCnt;
			current=current->Next;
		}
	}*/
	return iCnt;
}

int main()
{
	PNODE First = NULL;
	int iNo=0, iRet=0;
	
	InsertFirst(&First, 101);
	InsertFirst(&First, 51);
	InsertFirst(&First, 21);
	InsertFirst(&First, 11);

	Diaplay(First);

	printf("Enter number to search\t");
	scanf("%d",&iNo);
	
	iRet=SearchLastOcc(&First,iNo);
	printf("%d",iRet);
 return 0;
} 