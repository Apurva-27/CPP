/*
5. Write a program which display addition of digits of element from singly
linear linked list.
Function Prototype :int SumDigit( PNODE Head);
Input linked list : |110|->|230|->|20|->|240|->|640|
Output : 2 5 2 6 10 
*/

#include<stdio.h>
#include<stdlib.h>

struct Node
{
	int data;
	struct Node *next;
};

typedef struct Node NODE;
typedef struct Node *PNODE;
typedef struct Node **PPNODE;

void InsertFirst(PPNODE Head,int Value)
{
	PNODE newn=NULL;
	newn =(PNODE)malloc(sizeof(NODE));
	newn->data=Value;
	newn->next=NULL;
	
	if(*Head==NULL)
	{
		*Head = newn;
	}
	else
	{
		newn->next=(*Head);
		(*Head)=newn;
	}
}

void Display(PNODE Head)
{
	while(Head!=NULL)
	{
		printf("%d->",Head->data);
		Head = Head->next;
	}
	printf("NULL\n");
}

int Count(PNODE Head)
{		
	int iCnt=0;
	while(Head!=NULL)
	{
		iCnt++;
		Head = Head->next;
	}
	return iCnt;
}

int SumDigit( PNODE Head)
{
	int  Number=0,i=0,iResult=0,iSum=0,iSize=0;
	iSize=Count(Head);
	
	while(Head!=NULL)
	{		
			Number=Head->data;
			iSum=0;
			for(i=1;i<=iSize;i++)
			{
				while(Number!=0)
				{
					iResult =Number % 10;
					if(iResult==0)
					{
						iResult=1;
					}
					iSum=iSum+iResult;
					Number =Number/ 10;
				}
			
		}
		return iSum;
		//printf("%d\t",iMult);
		Head = Head->next;
	}
}

int main()
{
	PNODE First=NULL;
	int iNo=0, i=0, iTNo=0, iRet=0;
	
	printf("\nEnter nodes to be number\t");
	scanf("%d",&iTNo);
	
	for(i=1;i<=iTNo;i++)
	{	
		printf("\nEnter number\t");
		scanf("%d",&iNo);
		
		InsertFirst(&First,iNo);
		
		iRet=SumDigit(First);
		printf("%d\t\n",iRet);
	}
	Display(First);
	
	
	return 0;
}