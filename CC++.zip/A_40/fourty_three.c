/*
3. Write a program which returns addition of all even element from singly
linear linked list.
Function Prototype :int AdditionEven( PNODE Head);
Input linked list : |11|->|20|->|32|->|41|
Output : 52
*/


#include<stdio.h>
#include<stdlib.h>

struct Node
{
	int data;
	struct Node *next;
};

typedef struct Node NODE;
typedef struct Node *PNODE;
typedef struct Node **PPNODE;

void InsertFirst(PPNODE Head,int Value)
{
	PNODE newn=NULL;
	newn =(PNODE)malloc(sizeof(NODE));
	newn->data=Value;
	newn->next=NULL;
	
	if(*Head==NULL)
	{
		*Head = newn;
	}
	else
	{
		newn->next=(*Head);
		(*Head)=newn;
	}
}

void Display(PNODE Head)
{
	while(Head!=NULL)
	{
		printf("%d->",Head->data);
		Head = Head->next;
	}
	printf("NULL\n");
}

int Count(PNODE Head)
{		
	int iCnt=0;
	while(Head!=NULL)
	{
		iCnt++;
		Head = Head->next;
	}
	return iCnt;
}

int AdditionEven( PNODE Head)
{
	int  Number=0,i=0,iResult=0,iSum=0,iSize=0;
	iSize=Count(Head);
	
	while(Head!=NULL)
	{		
		Number=Head->data;
		for(i=1;i<=iSize;i++)
		{
			iResult = Number%2;
			if(iResult ==0)
			{
				iSum = iSum + Number;
			}
		}
		return iSum;
		Head = Head->next;
	}
}

int main()
{
	PNODE First=NULL;
	int iNo=0, i=0, iTNo=0, iRet=0;
	+
	printf("\nEnter nodes to be number\t");
	scanf("%d",&iTNo);
	
	for(i=1;i<=iTNo;i++)
	{	
		printf("\nEnter number\t");
		scanf("%d",&iNo);
		
		InsertFirst(&First,iNo);
		
	}
	Display(First);
	iRet=AdditionEven(First);
	printf("%d",iRet);

return 0;
}