/*
1. Write a program which reverse each element of singly linked list.
Function Prototype :
void Reverse( PNODE Head);
Input linked list : |11|->|28|->|17|->|41|->|6|->|89|
Output : |11|->|82|->|71|->|14|->|6|->|98|

*/

#include<stdio.h>
#include<stdlib.h>

struct Node
{
	int data;
	struct Node *next;
};

typedef struct Node NODE;
typedef struct Node *PNODE;
typedef struct Node **PPNODE;

void InsertFirst(PPNODE Head,int Value)
{
	PNODE newn=NULL;
	newn =(PNODE)malloc(sizeof(NODE));
	newn->data=Value;
	newn->next=NULL;
	
	if(*Head==NULL)
	{
		*Head = newn;
	}
	else
	{
		newn->next=(*Head);
		(*Head)=newn;
	}
}

void Display(PNODE Head)
{
	while(Head!=NULL)
	{
		printf("%d->",Head->data);
		Head = Head->next;
	}
	printf("NULL\n");
}

int Count(PNODE Head)
{		
	int iCnt=0;
	while(Head!=NULL)
	{
		iCnt++;
		Head = Head->next;
	}
	return iCnt;
}

void Reverse(PNODE Head)
{
	int i=0,iResult=0,Size=0,Number=0,Remender=1;
	
	Size=Count(Head);
	
	while(Head!=NULL)
	{
			Number=Head->data;
			for(i=1;i<=Size;i++)
			{
				while(Number!=0)
				{
					iResult =Number % 10;
					printf("%d",iResult);
					Number =Number/10;
				}
			}
		printf("->/NULL");
		Head = Head->next;
	}
}

int main()
{
	PNODE First=NULL;
	int iNo=0, i=0;
	
	for(i=1;i<=3;i++)
	{	
		printf("\nEnter number\t");
		scanf("%d",&iNo);
		InsertFirst(&First,iNo);
	}
	Display(First);
	Reverse(First);
	return 0;
}