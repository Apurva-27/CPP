
#include<stdio.h>
#include<stdlib.h>

struct Node
{
 int data;
 struct Node *next;
 struct Node *prev;
};

typedef struct Node NODE;
typedef struct Node * PNODE;
typedef struct Node ** PPNODE;

void InsertLast(PPNODE Head, PPNODE Tail, int value)
{
	PNODE newn = NULL;

	newn = (PNODE)malloc(sizeof(NODE));

	newn->data = value;
	newn->next = NULL;
	newn->prev = NULL;

	if((*Head ==NULL) && (*Tail == NULL)) // Linked list is empty
	{
		*Head = newn;
		*Tail = newn;
	}
	else // Linked list contains atleast one node
	{
		(*Tail)->next = newn;
		newn->prev = *Tail;
		*Tail = (*Tail) ->next; // *Tail = newn;
	}
	(*Tail)->next = *Head;
	(*Head)->prev = *Tail;
}

void InsertFirst(PPNODE Head, PPNODE Tail, int value)
{
	PNODE newn = NULL;

	newn = (PNODE)malloc(sizeof(NODE));

	newn->data = value;
	newn->next = NULL;
	newn->prev = NULL;

	if((*Head ==NULL) && (*Tail == NULL)) // Linked list is empty
	{
		*Head = newn;
		*Tail = newn;
	}
	else // Linked list contains atleast one node
	{
		newn->next = *Head;
		(*Head)->prev = newn;
		*Head = (*Head)->prev;
	}
	(*Tail)->next = *Head;
	(*Head)->prev = *Tail;
}

void InsertAtPos(PPNODE Head, PPNODE Tail, int value, int pos)
{
	int iCnt=0, i=0;
	iCnt = Count(*Head,*Tail);
	
	PNODE temp = *Head;
	
	PNODE newn = NULL;
	newn=(PNODE)malloc(sizeof(NODE));
	
	if((pos<1) || (pos>iCnt+1))
	{
		return;
	}
	if(pos==1)
	{
		InsertFirst(Head, Tail, value);
	}
	else if(pos==iCnt)
	{
		InsertLast(Head, Tail, value);
	}
	else
	{
		newn->data = value;
		newn->next = NULL;
		newn->prev = NULL;
		
		for(i=1; i<pos-1; i++)
		{
			temp=temp->next;
		}
		newn->next = temp->next;
		temp->next->prev = newn;
		
		temp->next = newn;
		newn->prev = temp;
	}	
}

void DeleteFirst(PPNODE Head, PPNODE Tail)
{
	if(*Head == NULL && *Tail==NULL)
	{
		return;
	}
	if(*Head == *Tail)
	{
		free(*Head);
		*Head=NULL;
		*Tail=NULL;
	}
	else
	{
		*Head = (*Head)->next;
		free((*Tail)->next);
		
		(*Head)->prev = *Tail;
		(*Tail)->next = *Head;
	}
}

void DeleteLast(PPNODE Head, PPNODE Tail)
{
	if(*Head == NULL && *Tail==NULL)
	{
		return;
	}
	if(*Head == *Tail)
	{
		free(*Head);
		*Head=NULL;
		*Tail=NULL;
	}
	else
	{
		*Tail=(*Tail)->prev;
		free((*Tail)->next);
		
		(*Tail)->next = *Head;
		(*Head)->prev = *Tail;
	}
}

void DeleteAtPos(PPNODE Head, PPNODE Tail, int pos)
{
	int iCnt=0, i=0;
	PNODE temp = *Head;
	iCnt = Count(*Head,*Tail);
	
 
}

void Display(PNODE Head, PNODE Tail)
{
	if((Head == NULL) && (Tail == NULL))
	{
		return;
	}
	do
	{
		printf("|%d| -> ",Head->data);
		Head = Head -> next;
	}while(Head != Tail -> next);
	printf("NULL");
}

int Count(PNODE Head, PNODE Tail)
{
	int iCnt=0;
	if((Head == NULL) && (Tail == NULL))
	{
		return -1;
	}
	do
	{
		iCnt++;
		Head = Head -> next;
	}while(Head != Tail -> next);
	
	return iCnt;
}

int main()
{
	PNODE First = NULL;
	PNODE Last = NULL; // Nawin
	int i=0, iNo = 0, choice=0, iRet=0, iTNo=0, iPos=0;

	while(1)
	{
		printf("\n---------------------------");
		printf("\n1)InsertFirst\n2)InsertLast\n3)InsertAtPos\n4)DeleteFirst\n5)DeleteLast\n6)DeleteAtPos\n7)Display\n8)Count\n9)Exit");
		printf("\nEnter your choice:\t");
		scanf("%d",&choice);
		printf("\n---------------------------");
		printf("\n");
		switch(choice)
		{
			case 1://InsertFirst
					printf("\nEnter number of nodes to be insert in linked list:");
					scanf("%d",&iTNo);
					
					for(i=1;i<=iTNo;i++)
					{
						printf("\nEnter number\t");
						scanf("%d",&iNo);
						InsertFirst(&First, &Last, iNo);
					}
			
			break;
			
			case 2://InsertLast
					printf("\nEnter number of nodes to be insert at last in linked list:");
					scanf("%d",&iTNo);
					
					for(i=1;i<=iTNo;i++)
					{
						printf("\nEnter number\t");
						scanf("%d",&iNo);
						InsertLast(&First, &Last, iNo);
					}
			break;
			
			case 3://InsertAtPos
					printf("\nEnter position number to insert node\t");
					scanf("%d",&iPos);
					
					printf("\nEnter number\t");
					scanf("%d",&iNo);
					
					InsertAtPos(&First, &Last, iNo, iPos);
					
			break;
			
			case 4://DeleteFirst
					DeleteFirst(&First, &Last);
			break;
			
			case 5://DeleteLast
					DeleteLast(&First, &Last);
			break;
			
			case 6://DeleteAtPos
					printf("\nEnter position number to delete node\t");
					scanf("%d",&iPos);
					
					DeleteAtPos(&First, &Last, iPos);

			break;
			
			case 7://Display
					Display(First,Last);
			break;
			
			case 8://Count
				iRet=Count(First,Last);
				printf("Number of nodes in Linked List are:\t%d",iRet);
			break;
			
			case 9:
					exit(0);
			break;
		}
	}
 return 0;
}