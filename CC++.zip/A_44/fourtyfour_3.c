/*
3.Write a recursive program which display below pattern.
Output : 5 4 3 2 1
*/
#include<stdio.h>

void Display()
{
	static int no=5;

	if(no>0)
	{
		printf("%d\t",no);
		no--;
		
		Display();
	}

}

int main()
{

 Display();

 return 0;
}