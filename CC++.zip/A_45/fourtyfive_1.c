/*
1. Write a recursive program which display below pattern.
Output : * * * * *
*/
#include<stdio.h>

void Display(int iNo)
{
	static int i=1;
	
	if(i<=5)
	{
		printf("*\t");
		i++;
		
		Display(iNo);
	}
}


int main()
{
	int iValue=0;
	
	printf("Enter value:");
	scanf("%d",&iValue);
 
	Display(iValue);
 
 return 0;
} 