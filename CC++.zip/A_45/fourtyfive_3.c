/*
3.Write a recursive program which display below pattern.
Output : 5 4 3 2 1
*/

#include<stdio.h>

void Display(int iNo)
{
	static int i=5;

	if(i>0)
	{
		printf("%d\t",i);
		i--;
		
		Display(iNo);
	}

}

int main()
{
	int iValue=0;
	
	printf("Enter value:");
	scanf("%d",&iValue);
 
	Display(iValue);

 return 0;
}