/*
4.Write a recursive program which display below pattern.
Input : 6
Output : A B C D E F
*/

#include<stdio.h>

void Display(int iNO)
{
	static char ch ='A';

	if(ch<='F')
	{
		printf("%c\t",ch);		
		ch++;
		Display(iNO);
	}

}

int main()
{
	int iValue=0;
	
	printf("Enter value:");
	scanf("%d",&iValue);
 
	Display(iValue);

 return 0;
}