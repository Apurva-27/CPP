/*
2. Write a recursive program which accept number from user and return
summation of its digits.
Input : 879
Output : 24
*/

#include<stdio.h>
int Sum(int iValue)
{
	int iResult=0, iSum=0;
	
	while(iValue!=0)
	{
		iResult=iValue%10;
		iSum=iSum+iResult;
		iValue=iValue/10;
		
		Sum(iValue);
	}
	return iSum;
}

int main()
{
	int iNo=0,iRet=0;

	printf("Enter number");
	scanf("%d",&iNo);
	
	iRet=Sum(iNo);
	printf("%d",iRet);
	
	return 0;
}