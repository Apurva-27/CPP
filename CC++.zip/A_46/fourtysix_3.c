/*
3. Write a recursive program which accept string from user and count number
of characters.
Input : Hello
Output : 5 
*/

#include<stdio.h>

int Strlen(char *str)
{
	int iCnt=0, i=0;
	
	while(str[i]!='\0')
	{
		iCnt++;
		i++;
		
		Strlen(str);
	}
	
	return iCnt;	
}

int main()
{
	int iRet=0;
	char arr[20];
	
	printf("Enter string:\t");
	scanf("%[^\n]",arr);
	
	iRet =Strlen(arr);
	printf("%d",iRet);

return 0;
}