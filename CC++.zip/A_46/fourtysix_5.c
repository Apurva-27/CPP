/*
5. Write a recursive program which accept number from user and return its
product of digits.
Input : 523
Output : 30 
*/

#include<stdio.h>

int Multipliction(int iNo)
{
	static int iResult=0,iMult=1;
	
	if(iNo<0)
	{
		iNo=-iNo;
	}
	
	while(iNo!=0)
	{
		iResult=iNo%10;
		if(iResult==0)
		{
			iResult=1;
		}
		iMult=iMult*iResult;
		iNo=iNo/10;
	}
	return iMult;
}

int main()
{
	int iValue=0, iRet=0;
	
	printf("Enter number:\t");
	scanf("%d",&iValue);
	
	iRet=Multipliction(iValue);
	printf("%d",iRet);
	
	return 0;
}