/*
1. Write a recursive program which accept string from user and count white
spaces.
Input : HE llo WOr lD
Output :3
*/ 

#include<stdio.h>

int WhiteSpaces(char str[])
{
	static int iCnt=0,i=0;
	
	if(str[i] != '\0')
    {
		if(str[i]==' ')
		{
			iCnt++;
		}
		i++;
		WhiteSpaces(str);
	}
	return iCnt;
}

int main()
{
	char arr[30];
	int iRet=0;
	
	printf("Enter String:");
	scanf(" %[^\n]s",arr);
	
	iRet=WhiteSpaces(arr);
	printf("%d",iRet);
	
	return 0;
	
}

/*
	OUTPUT
C:\Users\admin\Desktop\CC++\A_47>gcc fourtyseven_1.c -o myexe

C:\Users\admin\Desktop\CC++\A_47>myexe
Enter String:H E LL o
3
*/