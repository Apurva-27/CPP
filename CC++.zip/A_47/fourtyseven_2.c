/*
2. Write a recursive program which accept number from user and return
largest digit
Input : 87983
Output : 9
*/

#include<stdio.h>

int Max(int iNo)
{
	static int iResult=0,temp=0;

	while(iNo!=0)
	{
		iResult = iNo %10;
		
		if(temp<iResult)
		{
			temp = iResult;
		}
		iNo = iNo/10;
		Max(iNo);
	}
return temp;
} 

int main()
{
	int iNo=0,iRet=0;
	
	printf("Enter number\t");
	scanf("%d",&iNo);
	
	iRet=Max(iNo);
	printf("%d",iRet);

return 0;
}

/*
	OUTPUT

C:\Users\admin\Desktop\CC++\A_47>gcc fourtyseven_2.c -o myexe

C:\Users\admin\Desktop\CC++\A_47>myexe
Enter number    87983
9
*/