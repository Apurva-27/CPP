/*
3. Write a recursive program which accept string from user and count number
of small characters.
Input : HElloWOrlD
Output : 5 
*/

#include<stdio.h>

int SmallChar(char arr[])
{
	 static int i=0;
	 static int iCnt=0;
	
	while(arr[i]!=0)
	{
		if((arr[i]>='a')&&(arr[i]<='z'))
		{
			iCnt++;
		}
		i++;
		SmallChar(arr);
	}
	return iCnt;
}

int main()
{
	char arr[40];
	int iRet=0;
	
	printf("Enter string:\t");
	scanf("%[^\n]s",arr);
	
	iRet=SmallChar(arr);
	printf("Count of small letter:\t%d",iRet);
		
	return 0;
}

/*
	OUTPUT
C:\Users\admin\Desktop\CC++\A_47>gcc fourtyseven_3.c -o myexe

C:\Users\admin\Desktop\CC++\A_47>myexe
Enter string:   HElloWOrlD
Count of small letter:  5
*/