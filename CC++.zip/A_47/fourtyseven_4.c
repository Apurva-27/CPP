/*
4. Write a recursive program which accept number from user and return
smallest digit
Input : 87983
Output : 3 
*/

#include<stdio.h>

int Min(int iNo)
{
	int temp=0;
	int iResult=0;
	temp = iNo % 10;
	while(iNo!=0)
	{
		iResult = iNo %10;
		
		if(iResult<temp)
		{
			temp = iResult;
		}
		iNo = iNo/10;
		Min(iNo);
	}
return temp;
} 

int main()
{
	int iNo=0,iRet=0;
	
	printf("Enter number\t");
	scanf("%d",&iNo);
	
	iRet=Min(iNo);
	printf("%d",iRet);

return 0;
}

/*
	OUTPUT
	
C:\Users\admin\Desktop\CC++\A_47>gcc fourtyseven_4.c -o myexe

C:\Users\admin\Desktop\CC++\A_47>myexe
Enter number    87983
3
*/