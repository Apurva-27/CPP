/*
5. Write a recursive program which accept number from user and return its
reverse number.
Input : 523
Output : 325 
*/

#include<stdio.h>

int Reverse(int iNo)
{ 
	int iResult=0, iReverse=0;
	
	while(iNo!=0)
	{
		iResult = iNo % 10;
		iReverse = (iReverse*10)+iResult;
		iNo = iNo/10;
		
		Reverse(iNo);
	}
	
	return iReverse;
}

int main()
{
	int iNo=0,iRet=0;
	
	printf("Enter number\t");
	scanf("%d",&iNo);
	
	iRet=Reverse(iNo);
	printf("Reverse number is:%d",iRet);

return 0;
}

/*
	OUTPUT
C:\Users\admin\Desktop\CC++\A_47>gcc fourtyseven_5.c -o myexe

C:\Users\admin\Desktop\CC++\A_47>myexe
Enter number    2365
Reverse number is:5632
	
*/