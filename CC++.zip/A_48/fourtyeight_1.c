/*
1. Write application which accept file name from user and open that file in read mode.
Input : Demo.txt
Output : File opened successfully. 
*/

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>


int main()
{
	char FName[30]={'\0'};
	int fd=0;
	
	printf("Enter file name\t");
	scanf("%s",FName);
		
	fd = open(FName,O_RDWR);
	
	if(fd==-1)
	{
		printf("Unable to open");
	}
	else
	{
		printf("File open successfully %d",fd);
	}
	
	return 0;
}

/*
	OUTPUT
C:\Users\admin\Desktop\CC++\A_48>gcc fourtyeight_1.c -o myexe

C:\Users\admin\Desktop\CC++\A_48>myexe
Enter file name one.txt
File open successfully 3
*/