/*
2. Write application which accept file name from user and create that file.
Input : Demo.txt
Output : File created successfully. 
*/

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>

int main()
{
	char name[20]={'\0'};
	int fd=0;				
	
	printf("Enter file name\t");
	scanf("%s",name);
	
	fd = open(name ,O_RDWR | O_CREAT);
	fd = creat(name,0777);		
	
	if(fd==-1)
	{
		printf("Unable to creat file");
	}
	else
	{
		printf("File sucessfully created %d",fd);
	}
	
	return 0;
}

