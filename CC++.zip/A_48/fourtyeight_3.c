/*
3. Write application which accept file name from user and read all data from that file
and display contents on screen.
Input : Demo.txt
Output : Display all data of file. 
*/

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>

void ReadFile(char FName[])
{
	int fd=0,ret=0;
	char arr[100]={'\0'};
	
	fd = open(FName,O_RDONLY);
	if(fd == -1)
	{
		printf("Unable to read file");
		return;
	}
	
	printf("Data from file:\n");
	
	while((ret = read(fd,arr,100))!=0)
	{
		write(1,arr,ret);
	}
	
	close(fd);
}

int main()
{
	char Fname[50]={'\0'};
	
	printf("Enter file name\t");
	scanf("%s",Fname);
	
	ReadFile(Fname);
	
	return 0;
}