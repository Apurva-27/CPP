/*
4. Write application which accept file name from user and display size of file.
Input : Demo.txt
Output : File size is 56 bytes 
*/

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>

int CountBytes(char FName[])
{
	int fd=0,ret=0,iCnt=0,i=0;
	char arr[100]={'\0'};
	
	fd = open(FName,O_RDONLY);
	if(fd == -1)
	{
		printf("Unable to read file");
		return -1;
	}
	
	while((ret = read(fd,arr,sizeof(arr)))!=0)
	{
		for(i = 0; i<ret; i++)
		{
			iCnt++;
		}
	}
	close(fd);
	return iCnt;
}

int main()
{
	char Fname[50]={'\0'};
	int ret=0;
	printf("Enter file name\t");
	scanf("%s",Fname);
	
	ret = CountBytes(Fname);
	printf("Number of bytes in file are : %d",ret);
	
	return 0;
}

/*
OUTPUT


C:\Users\admin\Desktop\CC++\A_48>gcc fourtyeight_4.c -o myexe

C:\Users\admin\Desktop\CC++\A_48>myexe
Enter file name three.txt
Number of bytes in file are : 44
*/