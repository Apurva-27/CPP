/*
2. Write a program which accepts file name from user and count number of
small characters from that file.
Input : Demo.txt
Output : Number of small characters are 21 
*/


#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>


int FileSmallCount(char *name)
{
    int fd = 0, ret = 0,iCnt = 0, i = 0;
    char Mug[100];
    
    fd = open(name,O_RDONLY);
    if(fd == -1)
    {
        printf("Unable to open file\n");
        return -1;
    }
    
    while((ret = read(fd,Mug,sizeof(Mug))) != 0)
    {
        for(i = 0; i<ret; i++)
        {
            if((Mug[i] >= 'a') && (Mug[i] <= 'z'))
            {
                iCnt++;
            }
        }
    }
    
    close(fd);
    return iCnt;
}

int main()
{
    char name[20];
    int ret = 0;
    
    printf("Enter file name\n");
    scanf("%s",name);
    
   ret = FileSmallCount(name);
    
    printf("Number of small characters are : %d\n",ret);
    
    return 0;
}

/*
	Output

C:\Users\admin\Desktop\CC++\A_49>gcc fourtynine_2.c -o myexe

C:\Users\admin\Desktop\CC++\A_49>myexe
Enter file name
ont.txt
Number of small characters are : 14
	*/