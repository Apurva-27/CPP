/*
4. Write a program which accepts file name and one character from user and
count number of occurrences of that characters from that file.
Input : Demo.txt ‘M’
Output : Frequency of M is 7 
*/

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>


int FileFindM(char *name)
{
    int fd = 0, ret = 0,iCnt = 0, i = 0;
    char Mug[100];
    
    fd = open(name,O_RDONLY);
    if(fd == -1)
    {
        printf("Unable to open file\n");
        return -1;
    }
    
    while((ret = read(fd,Mug,sizeof(Mug))) != 0)
    {
        for(i = 0; i<ret; i++)
        {
            if(Mug[i] =='M')
            {
                iCnt++;
            }
        }
    }
    
    close(fd);
    return iCnt;
}

int main()
{
    char name[20];
    int ret = 0;
    
    printf("Enter file name\n");
    scanf("%s",name);
    
   ret = FileFindM(name);
    
    printf("Number of M in file are : %d\n",ret);
    
    return 0;
}

/*
	OUTPUT
C:\Users\admin\Desktop\CC++\A_49>gcc fourtynine_4.c -o myexe

C:\Users\admin\Desktop\CC++\A_49>myexe
Enter file name
ont.txt
Number of M in file are : 1

*/