/*
5. Write a program which accepts file name and one count from user and read
that number of characters from starting position.
Input : Demo.txt 12
Output : Display first 12 characters from Demo.txt
*/


#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>

void FileRead(char *name, int position)
{
    int fd = 0, ret = 0;
    char Mug[40] = {'\0'};
    fd = open(name,O_RDONLY);
    if(fd == -1)
    {
        printf("Unable to open file\n");
        return;
    }
    // Change the current offset
    ret = lseek(fd,position,SEEK_SET);
    printf("Return value of lseek : %d\n",ret);
    
    ret = read(fd,Mug,12);
    printf("Data from the file is : \n");
    
    printf("Return value of read : %d\n",ret);
    write(1,Mug,ret);
    
    printf("\n");
    close(fd);
}
int main()
{
    char name[20];
    int value = 0;
    
    printf("Enter file name\n");
    scanf("%s",name);
    
    printf("Enter the position\n");
    scanf("%d",&value);
    
    FileRead(name,value);
    
    return 0;
}

/*
	OUTPUT
C:\Users\admin\Desktop\CC++\A_49>gcc fourtynine_5.c -o myexe

C:\Users\admin\Desktop\CC++\A_49>myexe
Enter file name
ont.txt
Enter the position
1
Return value of lseek : 1
Data from the file is :
Return value of read : 12
ssiGnMenT Nu

*/