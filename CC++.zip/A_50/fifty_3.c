/*
3. Write a program which accept file name which 
contains information of student and isplay only 
names of students. 
*/


#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>

struct student
{
    int Rollno;
    char Name[20];
    int Marks;
};


void FileRead(char *name)
{
    int fd = 0, ret = 0, size = 0, i = 0;
    struct student sobj;
    
    fd = open(name,O_RDONLY);
    if(fd == -1)
    {
        printf("Unable to open file....\n");
        return ;
    }
    
    printf("..................Data from file is............... : \n");
    
    while((ret = read(fd,&sobj,sizeof(sobj)))!= 0)
    {
      printf("Name of student : %s\n",sobj.Name);
	}
    
    close(fd);
}


int main()
{
    char name[20];
    
    printf("Enter file name\n");
    scanf("%s",name);
    
    FileRead(name);
    
    return 0;
}