/*
1. Write Java program which accept N numbers from user and return
difference between summation of even elements and summation of
odd elements.
Input : N : 6
 Elements : 85 66 3 80 93 88
Output : 53 (234 - 181)
*/
import java.lang.*;
import java.util.*;

class ArrayDemo
{
	
	public int Difference(int arr[])
	{
		int even=0, odd=0, Diff=0;
		for(int i=0; i< arr.length; i++)
		{
			if((arr[i] % 2)==0)
			{
				even = even + arr[i];
			}
			else
			{
				odd = odd + arr[i];
			}
		}
		Diff = even - odd;
		return Diff;
	}

}

class Demo1
{
	public static void main(String arg[])
	{
		Scanner sobj = new Scanner(System.in);
		
		System.out.println("Enter number of elements");
		int size = sobj.nextInt();
		
		int arr[] = new int[size];
		
		System.out.println("Enter elements");
		for(int i = 0; i < arr.length; i++)
		{
			arr[i] = sobj.nextInt();
		}
		
		ArrayDemo dobj = new ArrayDemo();
		
		int iRet = dobj.Difference(arr);
		
		System.out.print("Difference between Even and Odd nubers :\t"+iRet);
	}
} 