/*
1. Write java program which accept N numbers from 
user and accept one another number as NO ,
check whether NO is present or not.
Input : N : 6
 NO: 66
 Elements : 85 66 3 66 93 88
Output : TRUE
Input : N : 6
 NO: 12
 Elements : 85 11 3 15 11 111
Output : FALSE 
*/

import java.lang.*;
import java.util.*;

class Number
{
	boolean Check(int arr[], int iNo)
	{
		int i=0;
		for(i=0; i< arr.length; i++)
		{
			if(arr[i]==iNo)
			{
				break;
			}
			else if(arr[i]!=iNo)
			{
				return false;
			}
		}
		
		if(arr[i]==iNo)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
} 

class Demo1
{
	public static void main(String arg[])
	{
		Scanner sobj = new Scanner(System.in);
		
		System.out.println("Enter number of elements");
		int size = sobj.nextInt();
		
		int arr[] = new int[size];
		
		System.out.println("Enter elements");
		for(int i = 0; i < arr.length; i++)
		{
			arr[i] = sobj.nextInt();
		}
		
		System.out.println("Enter number to search");
		int iVal = sobj.nextInt();
		
		Number nobj = new Number();
		
		boolean bRet=nobj.Check(arr,iVal);
		
		if(bRet==true)
		{
			System.out.println("Number exixts");
		}
		else
		{
			System.out.println("Number not exixts");
		}
	}
} 

