/*
2. Write java program which accept N numbers from user and accept
one another number as NO , return index of first occurrence of that
NO.
Input : N : 6
NO: 66
Elements : 85 66 3 66 93 88
Output : 1

Input : N : 6
NO: 12
Elements : 85 11 3 15 11 111
Output : -1 
*/

import java.lang.*;
import java.util.*;

class Number
{
	public int Check(int arr[], int iNo)
	{
		int i=0;
		for(i=0; i< arr.length; i++)
		{
			if(arr[i]==iNo)
			{
				break;
			}
			else if(arr[i]!=iNo)
			{
				return -1;
			}
		}
		
		if(arr[i]==iNo)
		{
			return i;
		}
		else
		{
			return -1;
		}
	}
}

class Demo2
{
	public static void main(String arg[])
	{
		Scanner sobj = new Scanner(System.in);
		
		System.out.println("Enter number of elements");
		int size = sobj.nextInt();
		
		int arr[] = new int[size];
		
		System.out.println("Enter elements");
		for(int i = 0; i <arr.length; i++)
		{
			arr[i] = sobj.nextInt();
		}
		
		System.out.println("Enter number to search");
		int iVal = sobj.nextInt();
		
		Number nobj = new Number();
		
		int iRet=nobj.Check(arr,iVal);
		
		System.out.print("First occurrence of numberfound at:\t"+iRet);
	}
}