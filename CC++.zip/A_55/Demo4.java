/*
4. Write java program which accept N numbers from user 
and accept Range, Display all elements from that range
Input : N : 6
 Start: 60

 End : 90

 Elements : 85 66 3 76 93 88
Output : 66 76 88
Input : N : 6
 Start: 30

 End : 50

 Elements : 85 66 3 76 93 88 
*/
import java.lang.*;
import java.util.*;

class Number
{
	public void Display(int arr[],int iStart, int iEnd)
	{
		int i=0;
		for(i=0; i<arr.length ;i++)
		{
			if((arr[i]>=iStart) && (arr[i]<=iEnd))
			{
				System.out.print("\t"+arr[i]);
			}
		}
	}
} 

class Demo4
{
	public static void main(String arg[])
	{
		Scanner sobj = new Scanner(System.in);
		
		System.out.println("Enter number of elements");
		int size = sobj.nextInt();
		
		int arr[] = new int[size];
		
		System.out.println("Enter elements");
		for(int i = 0; i < arr.length; i++)
		{
			arr[i] = sobj.nextInt();
		}
		
		System.out.println("Enter start number");
		int iStart = sobj.nextInt();
		
		System.out.println("Enter end number");
		int iEnd = sobj.nextInt();
				
		Number nobj = new Number();
		nobj.Display(arr,iStart,iEnd);
	}
}