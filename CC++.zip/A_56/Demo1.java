//1.Write a Java program which accept string from user and count
//number of capital characters.
//Input : "Marvellous Multi OS"
//Output : 4

import java.lang.*;
import java.util.*;

class StringDemo
{
	public int CountCapital(String str)
	{
		char arr[] = str.toCharArray();
		int size = arr.length;
		int i=0, iCnt=0;
		
		while(i < size)
		{
			if((arr[i] >= 'A') && (arr[i] <= 'Z'))
			{
				iCnt++;
			}
			i++;
		}
	return iCnt;
	}
} 

class Demo1
{
	public static void main(String arg[])
	{
		Scanner sobj = new Scanner(System.in);
		System.out.println("Enter string");

		String str = sobj.nextLine();
		
		StringDemo stobj = new StringDemo();
		
		int iRet = stobj.CountCapital(str);
		System.out.println("Count of capital letters\t"+iRet);		
	}
}