/*
2. Write a java program which accept string from user and count
number of small characters.
Input : "Marvellous"
Output : 9 
*/

import java.lang.*;
import java.util.*;

class StringDemo
{
	public int CountSmall(String str)
	{
		char arr[] = str.toCharArray();
		int size = arr.length;
		int i=0, iCnt=0;
		
		while(i < size)
		{
			if((arr[i] >= 'a') && (arr[i] <= 'z'))
			{
				iCnt++;
			}
			i++;
		}
	return iCnt;
	}
} 

class Demo2
{
	public static void main(String arg[])
	{
		Scanner sobj = new Scanner(System.in);
		System.out.println("Enter string");

		String str = sobj.nextLine();
		
		StringDemo stobj = new StringDemo();
		
		int iRet = stobj.CountSmall(str);
		System.out.println("Count of small letters\t"+iRet);		
	}
}