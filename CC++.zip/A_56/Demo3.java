/*
3. Write a java program which accept string from user and return
difference between frequency of small characters and frequency
of capital characters.
Input : MarvellouS
Output : 6 (8-2) 
*/


import java.lang.*;
import java.util.*;

class StringDemo
{
	public int CountDiff(String str)
	{
		char arr[] = str.toCharArray();
		int size = arr.length;
		int i=0, iCapCnt=0, iSmallCnt=0,iDiff=0;
		
		while(i < size)
		{
			if((arr[i] >= 'a') && (arr[i] <= 'z'))
			{
				iSmallCnt++;
			}
			else 
			{
				iCapCnt++;
			}
			i++;
		}
	iDiff = iSmallCnt - iCapCnt;
	return iDiff;
	}
} 

class Demo3
{
	public static void main(String arg[])
	{
		Scanner sobj = new Scanner(System.in);
		System.out.println("Enter string");

		String str = sobj.nextLine();
		
		StringDemo stobj = new StringDemo();
		
		int iRet = stobj.CountDiff(str);
		System.out.println("Count of small letters\t"+iRet);		
	}
}