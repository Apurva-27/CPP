/*4. Write a java program which accept string from user and check
whether it contains vowels in it or not.
Input : marvellous
Output : TRUE
Input : Demo
Output : TRUE
Input : xyz
Output : FALSE 
*/

import java.lang.*;
import java.util.*;
	
class DemoString
{
	boolean ChkVowels(String str)
	{
		char arr[] = str.toCharArray();
		int size = arr.length;
		int i=0;
		
		while(i < size)
		{
			if((arr[i]=='a') || (arr[i]=='A') ||(arr[i]=='e') || (arr[i]=='E') || (arr[i]=='i') || (arr[i]=='I') || (arr[i]=='o') || (arr[i]=='O') || (arr[i]=='u') || (arr[i]=='U'))
			{
				return true;
			}
			else if((arr[i]!='a') || (arr[i]!='A') ||(arr[i]!='e') || (arr[i]!='E') || (arr[i]!='i') || (arr[i]!='I') || (arr[i]!='o') || (arr[i]!='O') || (arr[i]!='u') || (arr[i]!='U')) 
			{
				return false;
			}
			i++;
		}
		
		if((arr[i]=='a') || (arr[i]=='A') ||(arr[i]=='e') || (arr[i]=='E') || (arr[i]=='i') || (arr[i]=='I') || (arr[i]=='o') || (arr[i]=='O') || (arr[i]=='u') || (arr[i]=='U'))
		{
			return true;
		}
		else 
		{
			return false;
		}
	}
}

class Demo4
{
	public static void main(String arg[])
	{
		Scanner sobj = new Scanner(System.in);
		System.out.println("Enter string");

		String str = sobj.nextLine();
		DemoString dobj = new DemoString();

		boolean ret = dobj.ChkVowels(str);
		
		if(ret == true)
		{
			System.out.println("Vowels exists");
		}
		else
		{
			System.out.println("Vowels not exists");
		}
	}
}
