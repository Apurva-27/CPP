/*5. Write a java program which accept string from user and display
it in reverse order.
Input : MarvellouS
Output : SuollevraM 
*/

import java.lang.*;
import java.util.*;

class DemoString
{
	public void Reverse(String str)
	{
		char arr[] = str.toCharArray();
		char temp;
		int size = arr.length;
		int i=0,iStart=0;
		int iEnd=arr.length-1;
		
		while(iStart < iEnd)
		{
			temp = arr[iStart];
			arr[iStart] = arr[iEnd];
			arr[iEnd] = temp;
			
			iStart++;
			iEnd--;
		}
		String sr = new String(arr);		
		System.out.println("Reverse string is\t"+sr);
	}
}

class Demo5
{
	public static void main(String arg[])
	{
		Scanner sobj = new Scanner(System.in);
		System.out.println("Enter string");

		String str = sobj.nextLine();
		DemoString dobj = new DemoString();

		dobj.Reverse(str);
	}
}
