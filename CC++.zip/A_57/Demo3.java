/*
3. Write Java program which accept number of rows and number of columns
from user and display below pattern.
Input : iRow = 3 iCol = 5
Output : 
 A A A A A
 B B B B B
 C C C C C
*/

import java.lang.*;
import java.util.*;

class Pattern
{
	public void Display(int iRow, int iCol)
	{
		int i=0, j=0, iCnt=0;
		int ch=64;
		
		if(iRow<0)
		{
			iRow = -iRow;
		}

		if(iCol<0)
		{
			iCol = -iCol;
		}				
		
		if((iRow <=0) || (iCol <=0))
		{
			return;
		}
		if((iRow <=0) || (iCol <=0))
		{
			return;
		}
		
		System.out.println();
		
		for(i=1;i<=iRow;i++)
		{
			for(j=1;j<=iCol;j++)
			{
				System.out.print((char)(ch+i)+"\t");
			}
			System.out.println();
		}
	}
}

class Demo3
{
	public static void main(String arg[])
	{
		Scanner sobj = new Scanner(System.in);
		
		System.out.println("Enter number of Rows");
		int iRow = sobj.nextInt();
		
		System.out.println("Enter number of Columns");
		int iCol = sobj.nextInt();
		
		Pattern pobj = new Pattern();
		pobj.Display(iRow,iCol);
	}
} 