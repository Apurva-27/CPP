/*
1. Write a java program which accepts 2 strings from user and
concat N characters of second string after first string.
Value of N should be accepted from user.
Note : If third parameter is greater than the size of second string
then concat whole string after first string.
Input : Marvellous Infosystems
 Logic Building
 5
Output : Marvellous Infosystems Logic
*/
 
import java.lang.*;
import java.util.*;

class StringDemo
{
	public String StrNCatX(String src, String dest, int iNO)
	{
		char arr[] = new char[iNO];
		
		int i=0;
		
		for(i=0; i<iNO; i++)
		{
			arr[i]=dest.charAt(i);
		}
		String sr =new String(arr);
		return src+sr;
	}
}

class Demo1
{
	public static void main(String arg[])
	{
		Scanner sobj =new Scanner(System.in);
		
		System.out.println("Enter String1");
		String src = sobj.nextLine();
		
		System.out.println("Enter String2");
		String dest = sobj.nextLine();
		
		System.out.println("Enter Number to concat");
		int Val = sobj.nextInt();
		
		StringDemo stobj = new StringDemo();
		
		String sret =stobj.StrNCatX(src,dest,Val);
	
		System.out.print("concat string\t"+sret);
	}
} 