/*
2. Write a program which 2 strings from user and check whether
contents of two strings are equal or not.
Input : Marvellous Infosystems
		Marvellous Infosystems
Output : TRUE 
*/
import java.lang.*;
import java.util.*;

class StringDemo
{
	public boolean StrCmpX(String src, String dest)
	{
		char arr[] = src.toCharArray();
		char brr[] = dest.toCharArray();
		int size = arr.length;
		
		if(src == dest)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}

class Demo2
{
	public static void main(String arg[])
	{
		Scanner sobj =new Scanner(System.in);
		
		System.out.println("Enter String1");
		String src = sobj.nextLine();
		
		System.out.println("Enter String2");
		String dest = sobj.nextLine();
		
		StringDemo stobj = new StringDemo();
		
		boolean sret = stobj.StrCmpX(src,dest);
		
		if(sret == true)
		{
			System.out.print("string are equal\t");
		}
		
	}
} 