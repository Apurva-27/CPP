#include<stdio.h>
#include<stdlib.h>

struct Node
{
	int data;
	struct Node *next;
	struct Node *prev;
};

typedef struct Node NODE;
typedef struct Node *PNODE;
typedef struct Node **PPNODE;

void InsertFirst(PPNODE Head, int Value)
{
	PNODE newn = NULL;
	newn = (PNODE)malloc(sizeof(NODE));
	newn->data=Value;
	newn->next=NULL;
	newn->prev=NULL;
	
	if(*Head ==NULL)
	{
		*Head = newn;
	}
	else
	{
		newn->next=*Head;
		(*Head)->prev=newn;
		*Head = newn;
	}
}

void Display(PNODE Head)
{
	while(Head!=NULL)
	{
		printf("%d<=>",Head->data);
		Head=Head->next;
	}
printf("NULL\n");
}

int Count(struct Node *Head)
{
	int iCnt=0;
	while(Head!=NULL)
	{
		iCnt++;
		Head = Head->next;
	}
	
	return iCnt;
}

void InsertLast(struct Node **Head, int Value)
{
	struct Node *newn=NULL;
	newn=(struct Node*)malloc(sizeof(struct Node));
	struct Node *temp =*Head;
	
	newn->data=Value;
	newn->next=NULL;
	newn->prev=NULL;
	
	if(*Head == NULL)
	{
		*Head = newn;
	}
	else
	{
		while(temp->next!=NULL)
		{
			temp=temp->next;
		}
		
		temp->next=newn;
		temp->prev=temp;
	}
}

void DeleteFirsrt(PPNODE Head)
{
	if(*Head == NULL)
	{
		return;
	}
	else if((*Head)->next == NULL)
	{
			free(*Head);
			*Head = NULL;
	}
	else
	{
		*Head = (*Head)->next;
		free((*Head)->prev);
		(*Head)->prev=NULL;
	}		
}

void InsertAatPos(PPNODE Head,int Value,int Pos)
{
	int size=0, i=0;
	size =Count(*Head);
	PNODE temp = *Head;
	PNODE newn=NULL;
	
	if((Pos<1)||(Pos>size+1))
	{
		return;
	}
	
	if(Pos==1)
	{
		InsertFirst(Head,Value);
	}
	else if(Pos==size+1)
	{
		InsertLast(Head,Value);
	}
	else
	{
		
	newn=(PNODE)malloc(sizeof(NODE));
	newn->data=Value;
	newn->next=NULL;
	newn->prev=NULL;
		
		for(i=1; i<Pos-1; i++)
		{
			temp=temp->next;
		}
		newn->next = temp->next;
		temp->next->prev=newn;
		
		temp->next = newn;
		newn->prev = temp;
	}
}

void DisplayX(PNODE Head)
{	
	if(Head == NULL)
	{
		return;
	}
	//travell till last
	while(Head->next != NULL)
	{
		Head = Head->next;
	}
	
	while(Head!= NULL)
	{
		printf("%d->\t",Head->data);
		Head = Head->prev;
	}
}

int main()
{
	PNODE First=NULL;
	int No=0, TNo=0, Pos=0, PNo=0, i=0, iRet=0;
	
	//InsertFirst
	printf("\nEnter Number of element to insert in Linked List\t");
	scanf("%d",&TNo);
	
	for(i=1; i<=TNo; i++)
	{
		printf("Enter Number\t");
		scanf("%d",&No);
		
		InsertFirst(&First,No);

	}	
	printf("\nDoubly Linked List is:\t");
	Display(First);

	//InsertAatPos
	printf("Enter Pos\t");
	scanf("%d",&Pos);
	printf("Enter Number\t");
	scanf("%d",&PNo);
	InsertAatPos(&First,PNo,Pos);
	Display(First);
	
	//Count
	printf("\nElements in linked list is:\t ");
	iRet=Count(First);
	printf("%d",iRet);
	
	//DeleteFirsrt
	printf("\nAfter Deleting First Element in linked list:\t");	
	DeleteFirsrt(&First);
	Display(First);
	
	//InsertLast
	printf("\nEnter Number of element to insert in Linked List\t");
	scanf("%d",&TNo);
	
	for(i=1; i<=TNo; i++)
	{
		printf("Enter Number\t");
		scanf("%d",&No);
		
		InsertLast(&First,No);
	}	
	printf("\nDoubly Linked List after inserting element in last position:\t");
	Display(First);
	
	//DisplayX
	printf("Reverse Display\n");
	DisplayX(First);
	
	return 0;
}