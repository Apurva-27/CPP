#include<iostream>
using namespace std;

typedef struct Node
{
	int data;
	struct Node *next;
	struct Node *prev;
}NODE,*PNODE;

class DoublyLL
{
 private:
	PNODE Head;
	int iSize=0;
	
 public:
	DoublyLL();					//Constructor
	void Display();
	int Count();
	void InsertFirst(int);
	void InsertLast(int);
	void InsertAtPos(int ,int);
	void DeleteFirst();
	void DeleteLast();
	void DeleteAtPos(int);
};

DoublyLL::DoublyLL()
{
	Head = NULL;
	iSize = 0;
	
}

void DoublyLL::Display()
{
	PNODE temp = Head;
	
	while(temp!=NULL)
	{
		cout<<temp->data<<"->";
	}
	cout<<"NULL";
}

int DoublyLL::Count()
{
	return iSize;
}

void DoublyLL::InsertFirst(int Value)
{
	PNODE newn = new NODE;
	newn->data = Value;
	newn->next = NULL;
	newn->prev = NULL;
	
	if(Head == NULL)
	{
		Head = newn;
	}
	else
	{
		newn->next = Head;
		Head->prev = newn;
		Head = newn;
	}
	iSize++;
}

void DoublyLL::InsertLast(int Value)
{
	PNODE temp = NULL;
	PNODE newn = new NODE;
	newn->data = Value;
	newn->next = NULL;
	newn->prev = NULL;
	
	if(Head == NULL)
	{
		Head = newn;
	}
	else
	{
		while(temp->next!=NULL)
		{
			temp=temp->next;
		}
		temp->next = newn;
		newn->next = NULL;
	}
	iSize++;
}

void DoublyLL::InsertAtPos(int Value,int Pos)
{
	if((Pos <1)||(Pos>iSize+1))
	{
		return;
	}
	if(Pos==1)
	{
		InsertFirst(Value);
	}
	else if(Pos==iSize+1)
	{
		InsertLast(Value);
	}
	else
	{
		PNODE temp =NULL;
		PNODE newn =new NODE;
		newn->data=Value;
		
		for(int i=1;i<Pos-1;i++)
		{
			temp=temp->next;
		}
		newn->next = temp->next;
		temp->next->prev=newn;
		temp->next = newn;
		newn->prev = temp;
		
		iSize++;
	}
}

void DoublyLL::DeleteFirst()
{
	
}

void DoublyLL::DeleteLast()
{
	
}

void DoublyLL::DeleteAtPos(int Pos)
{
	
}

int main()
{
	DoublyLL obj1;
	
	int choice=0,iNo=0,i=0,iTNO=0,iPos=0;
	
	while(choice)
	{
		cout<<"Enter choice\n";
		cout<<"1.Display\n";
		cout<<"2.Count\n";
		cout<<"3.InsertFirst\n";
		cout<<"4.InsertLast\n";
		cout<<"5.InsertAtPos\n";
		cout<<"6.DeleteFirst\n";
		cout<<"7.DeleteLast\n";
		cout<<"8.DeleteAtPos\n";
		cout<<"0.Exit\n";
		cin>>choice;
		
		switch(choice)
		{
			case 1:
					
			break;
			
			case 2:
			break;
			
			case 3:
					cout<<"Enter node to be insert:";
					cin>>iTNO;
					for(int i=1;i<=iTNO;i++)
					{	
						cout<<"Enter no:";
						cin>>iNo;
						obj1.InsertFirst(iNo);
					}
			break;
			
			case 4:
					cout<<"Enter node to be insert:";
					cin>>iTNO;
					for(int i=1;i<=iTNO;i++)
					{	
						cout<<"Enter no:";
						cin>>iNo;
						obj1.InsertLast(iNo);
					}
			break;
			
			case 5:
					cout<<"Enter at which position node to be insert:";
					cin>>iPos;
					
					cout<<"Enter no:";
					cin>>iNo;
					
					obj1.InsertAtPos(iPos,iNo);
			break;
			
			case 6:
			break;
			
			case 7:
			break;
			
			case 8:
			break;
			
			case 0:
					exit(0);
			break;
		}
	}

	return 0;
}