/*
2. Write a program which 2 strings from user and check whether
contents of two strings are equal or not. (Implement strcmp()
function).
Input : “Marvellous Infosystems”
		“Marvellous Infosystems”
Output : TRUE
*/

#include<stdio.h>
typedef int BOOL;
#define TRUE 1
#define FALSE 0

BOOL StrCmpX(char *src, char * dest)
{
 // Filter
 while((*src !='\0') && (*dest !='\0'))
 {
	if(*src == *dest )
	{
		break;
	}
 }

if(*src =='\0' && *dest=='\0' )
{
	return TRUE;
}
else
{
	return FALSE;
}
}
int main()
{
	char arr[40]="Marvellous Infosystems";
	char brr[40]="Marvellous Infosystems";
	
	BOOL bret = FALSE;
	bret= StrCmpX(arr,brr);
	
if(bret == TRUE)
 {
printf("Both strings are equal");
 }
 else
 {
 printf("Both strings are not equal");
 }
 return 0;
}