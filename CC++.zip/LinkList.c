#include<stdio.h>
#include<stdlib.h>

struct Node
{
	int data;
	struct Node *next;
};

typedef struct Node NODE;
typedef struct Node *PNODE;
typedef struct Node **PPNODE;

void InsertFirst(PPNODE Head,int Value)
{
	PNODE newn = NULL;
	newn = (PNODE)malloc(sizeof(NODE));
	
	newn->data=Value;
	newn->next = NULL;
	
	if(*Head==NULL)
	{
		*Head = newn;
	}
	else
	{
		newn->next=*Head;
		*Head = newn;
	}
}

void Display(PNODE Head)
{
	while(Head!=NULL)
	{
		printf("%d ->",Head->data);
		Head = Head->next;
	}
	printf("NULL\n");
}

int Count(PNODE Head)
{
	int iCnt=0;
	
	while(Head!=NULL)
	{
		iCnt++;
		Head = Head->next;
	}
	return iCnt;
}

void InsertLast(PPNODE Head, int Value)
{
	PNODE newn = NULL;
	
	PNODE temp = *Head;
	
	newn=(PNODE)malloc(sizeof(NODE));
	newn->data=Value;
	newn->next=NULL;
	
	if(*Head==NULL)
		
	{
		*Head = newn;
	}
	else
	{
		while(temp->next !=NULL)
		{
			temp = temp->next;
		}
		temp->next=newn;
	}
}

/*if(*Head == NULL){}
	else{}*/
void DeleteFirst(PPNODE Head)
{
	PNODE temp = *Head;
	
	if(*Head != NULL)
	{
		*Head = (*Head)->next;
		free(temp);
	}
}

void DeleteLast(PPNODE Head)
{
	if(*Head == NULL)	//if linked list is empty
	{
		return;
	}
	else if((*Head)-> next ==NULL) //linked list contains single node
	{
		free(*Head);
		*Head = NULL;
	}
	else	// linked list contains more than that
	{
		PNODE temp = *Head;
		
		while(temp->next->next!=NULL)
		{	
			temp = temp->next;
		}
		free(temp->next);
		temp->next=NULL;
	}
	/*
		PNODE temp = *Head;
		
		//Loop 1
		100->next!=NULL,(200)->next!=NULL,(300)->next!=NULL,(400)->next!=NULL,(500)->next=NULL
		while(temp != NULL) //ha loop NULL=NULL hoiparyant phirel jeva NULL=NULL hoil teva
							//loop while madhum baher padel
		{
			temp = temp->next;
		}
		
		//Loop 2
		100->next!=NULL,(200)->next!=NULL,(300)->next!=NULL,(400)->next!=NULL,(500)->next
		 while(temp->next!=NULL)
		{
			temp = temp->next;
		}
		 
		//Loop 3
		100->next!=NULL,(200)->next!=NULL,(300)->next!=NULL,(400)->next!=NULL
		while(temp->next->next!=NULL)
		{
			temp = temp->next;
		}
	*/
}

/*
invalid position -> return
first position	 -> Call InsertFirst
last position	 -> Call InsertLast
position between first and last ->write separate logic
*/
void InsertAtPos(PPNODE Head , int Value , int Pos)
{
	int Size=0,i=0;
	PNODE newn = NULL;
	PNODE temp=*Head;
	
	Size =Count(*Head);
		
	if((Pos < 1)||(Pos > Size+1))	//invalid position
	{
		return;
	}
	else if(Pos==1)					//first position
	{
		InsertFirst(Head , Value);
	}
	else if(Pos==Size+1)			//Last position
	{
		InsertLast(Head , Value);
	}
	else							//at position
	{	
		newn=(PNODE)malloc(sizeof(NODE)); 
		
		newn->data =Value;
		
		for(i=1 ; i<Pos-1 ;i++)
		{
			temp = temp->next;
		}
		
		newn->next = temp->next;
		temp->next = newn;
	}
}

void DeleteAtPos(PPNODE Head, int Pos)
{
		int Size = 0 , i=0;
		Size = Count(*Head);

		PNODE temp=*Head;
		PNODE temp2 = temp->next;
	
		if((Pos<1) || (Pos > Size))
		{
			return;
		}
		
		if(Pos == 1)
		{
			DeleteFirst(Head);
		}
		else if(Pos == Size)
		{
			DeleteLast(Head);
		}
		else
		{
			temp = *Head;
			for(i=1 ; i < Pos-1; i++)
			{
				temp= temp->next;
		    }
			temp2 = temp->next;
			temp->next=temp2->next;
			free(temp2);
		}
}

int main()
{
	PNODE First= NULL;
	int No= 0, iRet=0, Pos=0;
	
	printf("Enter Number:\t");
	scanf("%d",&No);
	
	InsertFirst(&First,No);
	
	printf("Enter Number:\t");
	scanf("%d",&No);
	
	InsertFirst(&First,No);
	
	printf("Enter Number:\t");
	scanf("%d",&No);
	
	InsertFirst(&First,No);
	
	printf("Enter Number:\t");
	scanf("%d",&No);
	
	InsertFirst(&First,No);
	
	Display(First);

	printf("Enter Number:\t");
	scanf("%d",&No);
	
	InsertLast(&First,No);

	Display(First);

	printf("Enter Number:\t");
	scanf("%d",&No);
	
	InsertLast(&First,No);

	Display(First);

	iRet=Count(First);
	printf("\nNodes in List are %d",iRet);

	printf("\nEnter position to insert number\t");
	scanf("%d",&Pos);
	
	printf("Enter number to insert at position %d\t",Pos);
	scanf("%d",&No);
	
	InsertAtPos(&First,No,Pos);
	
	printf("After adding at position\n");
	Display(First);
	
	iRet=Count(First);
	printf("\nNodes in List are %d",iRet);
	
	DeleteFirst(&First);
	
	printf("After Deletion of first NODE\n");
	
	Display(First);
	
	DeleteLast(&First);
	
	printf("After Deletion of last NODE\n");
	
	Display(First);
	
	iRet=Count(First);
	printf("\nNodes in List are %d",iRet);
	
	DeleteAtPos(&First,2);
	Display(First);
	
	return 0;
}