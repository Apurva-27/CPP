#include<stdio.h>
#include<stdlib.h>

struct Node
{
	int data;
	struct Node *next;
};

typedef struct Node NODE;
typedef struct Node *PNODE;
typedef struct Node **PPNODE;

void InsertFirst(PPNODE Head, int iNo)
{
	PNODE newn = NULL;
	newn = (PNODE)malloc(sizeof(NODE));
	
	newn->data = iNo;
	newn->next = NULL;
	
	if(*Head == NULL)
	{
		*Head = newn;
	}
	else
	{
		newn-> next =*Head;
		*Head = newn;
	}
}

void InsertLast()
{
	
}

void InsertAtPos()
{
	
}

void DeleteFirst()
{                                                                                                                                                                                                                                                                                                           
	
}

void DeleteLast()
{
	
}

void DeleteAtPos()
{
	
}

void Display(PNODE Head)
{
	while(Head!=NULL)
	{
		printf("%d\t",Head->data);
		Head=Head->next;
	}
}

int Count(PNODE Head)
{
	int iCnt=0;
	while(Head!=NULL)
	{
		iCnt++;
		Head=Head->next;
	}
	return iCnt;	
}

int main()
{
	PNODE First = NULL;
	int iNo=0, iTotalNo=0, iRet=0, i=0, iIndex=0;

	while(1)
	{
		printf("\n1)Insert Element at First\n2)Insert Element at Last\n3)Insert Element at Position");
		printf("\n4)Delete Element at First Position\n5)Delete Element at Last Position\n6)Delete Element at Position");
		printf("\n7)Display Linked List\n8)Count Elements in Linked List\n9)Exit");
		printf("\nEnter your Choice to perform operation\t");
		scanf("%d",&iIndex);
		
		switch(iIndex)
		{
			case 1:
					printf("\nEnter total number of elements to insert in linked list:\t");
					scanf("%d",&iTotalNo);
					
					for(i=1; i<=iTotalNo; i++)
					{
						printf("\nEnter number:\t");
						scanf("%d",&iNo);
						InsertFirst(&First,iNo);
					}
			break;
			
			case 2:
			
			break;
			
			case 3:
			
			break;
			
			case 4:
			
			break;
			
			case 5:
			
			break;
			
			case 6:
			
			break;
			
			case 7:
					Display(First);
			break;
			
			case 8:
					iRet=Count(First);
					printf("\nElements in linked list are:\t%d",iRet);
			break;
			
			case 9:
					exit(0);
			break;
			
			default : printf("\nInvalid option\n");
		}//switch
	
	}//while
	
return 0;
}