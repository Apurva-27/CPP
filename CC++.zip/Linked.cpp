#include<iostream>
using namespace std;

typedef struct Node
{
	int data;
	struct Node *next;
	struct Node *prev;
}NODE,*PNODE;

class DoublyLL
{
 private:
	PNODE Head;
	int iSize=0;
	
 public:
	DoublyLL();					//Constructor
	void Display();
	int Count();
	void InsertFirst(int);
	void InsertLast(int);
	void InsertAtPos(int ,int);
	void DeleteFirst();
	void DeleteLast();
	void DeleteAtPos(int);
};
DoublyLL::DoublyLL()
{
	Head = NULL;
	iSize = 0;
	
}

void DoublyLL::Display()
{
	PNODE temp = Head;
	
	while(temp!=NULL)
	{
		cout<<temp->data<<"->";
		temp=temp->next;
	}
	cout<<"NULL";
}

int DoublyLL::Count()
{
	return iSize;
}

void DoublyLL::InsertFirst(int Value)
{
	PNODE newn = new NODE;
	newn->data = Value;
	newn->next = NULL;
	newn->prev = NULL;
	
	if(Head == NULL)
	{
		Head = newn;
	}
	else
	{
		newn->next = Head;
		Head->prev = newn;
		Head = newn;
	}
	iSize++;
}

void DoublyLL::InsertLast(int Value)
{
	PNODE temp = Head;
	PNODE newn = new NODE;
	
	newn->data = Value;
	newn->next = NULL;
	newn->prev = NULL;
	
	if(Head == NULL)
	{
		Head = newn;
	}
	else
	{
		while(temp->next!=NULL)
		{
			temp=temp->next;
		}
		temp->next = newn;
		newn->next = NULL;
	}
	iSize++;
}

void DoublyLL::InsertAtPos(int Value,int Pos)
{
	if((Pos <1)||(Pos>iSize+1))
	{
		return;
	}
	if(Pos==1)
	{
		InsertFirst(Value);
	}
	else if(Pos==iSize+1)
	{
		InsertLast(Value);
	}
	else
	{
		PNODE temp =Head;
		PNODE newn =new NODE;
		
		newn->data=Value;
		newn->next=NULL;
		newn->prev=NULL;
		
		for(int i=1;i<Pos-1;i++)
		{
			temp=temp->next;
		}
		newn->next = temp->next;
		temp->next->prev=newn;
		temp->next = newn;
		newn->prev = temp;
		
		iSize++;
	}
}

void DoublyLL::DeleteFirst()
{	
	if(Head==NULL)
	{
		return;
	}
	else if(Head->next == NULL)
	{
		delete(Head);
		Head = NULL;
	}
	else
	{
		Head = Head->next;
		free(Head->prev);
		Head->prev = NULL;
	}
}

void DoublyLL::DeleteLast()
{
	
}

void DoublyLL::DeleteAtPos(int Pos)
{
	
}

int main()
{
	DoublyLL obj1;
	
	int choice=0,iNo=0,i=0,iTNO=0,iPos=0,iRet=0;
	
	while(1)
	{
		cout<<"\nEnter choice\n";
		cout<<"1.InsertFirst\n";
		cout<<"2.InsertLast\n";
		cout<<"3.InsertAtPos\n";
		cout<<"4.DeleteFirst\n";
		cout<<"5.DeleteLast\n";
		cout<<"6.DeleteAtPos\n";
		cout<<"7.Display\n";
		cout<<"8.Count\n";
		cout<<"0.Exit\n";
		
		cin>>choice;
	
		switch(choice)
		{
			case 1:
					cout<<"Enter node to be insert:";
					cin>>iTNO;
					for(int i=1;i<=iTNO;i++)
					{	
						cout<<"Enter no:";
						cin>>iNo;
						obj1.InsertFirst(iNo);
					}
			break;
			
			case 2:
					cout<<"Enter node to be insert:";
					cin>>iTNO;
					for(int i=1;i<=iTNO;i++)
					{	
						cout<<"Enter no:";
						cin>>iNo;
						obj1.InsertLast(iNo);
					}
			break;
			
			case 3:
					cout<<"Enter at which position node to be insert:";
					cin>>iPos;
					
					cout<<"Enter no:";
					cin>>iNo;
					
					obj1.InsertAtPos(iPos,iNo);
			break;
			
			case 4:
					obj1.DeleteFirst();
			break;
			
			case 5:
					
			break;
			
			case 6:
			break;
			
			case 7:
					obj1.Display();
			break;
			
			case 8:
					iRet=obj1.Count();
					cout<<"Nodes in list are %d\t"<<iRet;
			break;
			
			case 0:
					exit(0);
			break;
		}
	}
	return 0;
}