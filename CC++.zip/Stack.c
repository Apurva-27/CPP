#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
	int data;
	struct node *next;
};

typedef struct node NODE;
typedef struct node* PNODE;
typedef struct node** PPNODE;

void Push(PPNODE Head,int Value)//InsertFirst
{
	PNODE newn = (PNODE)malloc(sizeof(NODE));
	newn->data=Value;
	newn->next=NULL;
	
	if(*Head == NULL)
	{
		*Head = newn;
	}
	else
	{
		newn->next=*Head;
		*Head=newn;
	}
}

void Pop(PPNODE Head)
{
	int iNo=0;
	PNODE temp=*Head;
	
	if(*Head==NULL)
	{
		printf("Stack empty\n");
		return -1;
	}
	else
	{
		iNo=(*Head)->data;
		*Head = (*Head)->next;
		free(temp);
		return iNo;
	}
}

void Dispay(PNODE Head)
{
	while(Head!=NULL)
	{
		printf("%d->",Head->data);
		Head=Head->next;
	}
}

void Count(PNODE Head)
{
	int iCnt=0;
	while(Head!=NULL)
	{
		iCnt++;
		Head=Head->next;
	}
	return iCnt;
}


int main()
{
	int choice=0,iNo=0;
	PNODE First=NULL;
	
	printf("Dynamic implementation of stack\n");
	
	while(choice!=0)
	{
		printf("\n1.Push the elemeny\n2.POP the elemeny
		\n3.Dispay the elemeny\n4.Count number of element in satck");
		printf("Enter your choice\t");
		scanf("%d",&choice);
		
		switch(choice)
		{
			case 1:
				printf("Enter element that you want to insert\n");
				scanf("%d",&iNo);
				Push(&First,iNo);
			break;
			
			case 2:
			break;
			
			case 3:
			break;
			
			case 4:
			break;
		}
	}
}