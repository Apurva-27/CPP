#include<stdio.h>

int Add(int iNo1,int iNo2)
{
	int iAns =1;
	iAns = iNo1 * iNo2;
	
	return iAns;
	
}

int main()
{
	int iValue1 = 0 , iValue2 = 0 , iRet = 0;
	
	printf("Enter two numbers\t");
	scanf("%d %d",&iValue1 ,&iValue2);
	
	iRet = Add(iValue1,iValue2);
	
	printf("Addition of two nuber is:\t%d",iRet);
}