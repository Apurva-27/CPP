#include<stdio.h>

int Add(int iNo1, int iNo2)
{
   int Addition = 0;
   Addition=iNo1+iNo2;

   return Addition;
}

int main()
{
    int iV1=0 ,iV2=0 ,iRet=0;

    printf("Enter value1 and value2:");
    scanf("%d %d",&iV1,&iV2);

    iRet=Add(iV1,iV2);

    printf("Result is:\t %d",iRet);
}