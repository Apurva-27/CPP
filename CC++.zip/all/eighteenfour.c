/*
4. Accept number of rows and number of columns from user and display below
pattern.
Input : iRow = 6 iCol = 6
Output : 
 * * * * * *
 * *       *
 *   *     *
 *     *   *
 *       * *
 * * * * * * 
 */

#include<stdio.h>

void Pattern(int iRow, int iCol)
{
    int i=0, j=0;

    if(iRow<=0)
    {
        iRow = -iRow;
    }

    if(iCol<=0)
    {
        iCol = -iCol;
    }

    if(iRow!=iCol)
    {
        printf("Error:Invalid input.\n");
        return;
    }
    
    for(i=1; i<=iRow; i++) 
    {
        for(j=1; j<=iCol; j++)
        {
            if(i==j || i==1 || j==1 || j==iCol ||i==iCol)
            {
                printf("*\t");
            }
            else
            {
                printf("\t");
            }
            
        }
        printf("\n");
    }
}

int main()
{
 int iValue1 = 0, iValue2 = 0;
 
 printf("Enter number of rows\t");
 scanf("%d",&iValue1);
 
 printf("Enter number of columns\t");
 scanf("%d", &iValue2);
 
 Pattern(iValue1, iValue2);
 
 return 0;
} 