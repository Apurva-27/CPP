/*
3. Write a program which accept string from user and copy capital
characters of that string into another string.
Input : “Marvellous Multi OS”
Output : “MMOS” 
*/

#include<stdio.h>

void StrCpyCap(char *src, char *dest)
{
 while(*src != '\0')
 {
	if((*src >= 'A') && (*src<='Z'))
	{
		*dest = *src;
		src++;
	}
 dest++;
 }
 
 dest='\0';
} 

int main()
{
	char str[40]="Marvellous Multi OS";
	char brr[40];
	
	StrCpyCap(str,brr);
	
	printf("Asked string is:%s",brr);
	
return 0;
}