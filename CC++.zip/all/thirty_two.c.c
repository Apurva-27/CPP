/*
2. Write a program which accept string from user and copy the
contents of that string into another string. (Implement strncpy()
function)
Input : “Marvellous Multi OS”
 10
Output : “Marvellous
Note : If third parameter is greater than the size of source string then
copy whole string into destina
*/

#include<stdio.h>

void StrNCpy(char *str, char *dest, int iVal)
{
	while((*src!='\0') && (iVal!=0))
	{
		*dest = *src;
		src++;
		dest++;
		iVal--;
	}
	
	*dest='\0';
}

int main()
{
	char str[40]="Marvellous Multi OS";
	char brr[40];
	
	StrNCpy(str,brr,10);
	
	printf("Asked string is:%s",brr);
	
return 0;
}