/*
5. Write a program which accept one number from user and toggle contents
of first and last nibble of the number. Return modified number. (Nibble is a
group of four bits) 
*/

#include<stdio.h>

int Togg(int iNo)
{
	int iMask=0xF000000F;
	int iResult=0;
	
	if(iNo < 0)
    {
        iNo = -iNo;
    }
	
	iResult = iNo ^ iMask;
	
	return iResult;	
}

int main()
{
	int iNo=0, iRet=0;

	printf("Enter Number:\t");
	scanf("%d",&iNo);
	
	iRet=Togg(iNo);
	
	printf("Modified number is %d",iRet);

return 0;
}