/*
1.Write a program which accept one number and position from user and
check whether bit at that position is on or off. If bit is one return TURE
otherwise return FALSE.
Input : 10 2
Output : TRUE 
*/
#include<stdio.h>
typedef int BOOL;
#define TRUE 1
#define FALSE 0

BOOL BitChk(int iNo, int iPos)
{
	int iMask=0x00000001;
	int iResult=0;
	
	if(iNo < 0)
    {
        iNo = -iNo;
    }
    
    if((iPos < 1) || (iPos > 32))
    {
        return 0;
    }
	
	iMask= iMask<<(iPos-1);
	
	iResult = iNo & iMask;
	
	if(iResult == iMask)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

int main()
{
	int iNo=0, iPos=0;
	BOOL bRet =FALSE;
	
	printf("Enter Number:\t");
	scanf("%d",&iNo);
	
	printf("Enter Position:\t");
	scanf("%d",&iPos);

	
	bRet=BitChk(iNo,iPos);
	
	if(bRet==TRUE)
	{
		printf("Bit is on");
	}
	else
	{
		printf("Bit is off");
	}
	
return 0;
}