/*
5. Write a program which accept string from user and copy that
characters of that string into another string by toggling the case.
Input : “Marvellous Python 2”
Output : “mARVELLOUS pYTHON 2”
*/

#include<stdio.h>

void StrCpyToggle(char *src, char *dest)
{
	while(*src!='\0')
	{
		*dest=*src;
		
		if((*dest>='A')&&(*dest<='Z'))
		{
			*dest= *dest+32;
		}
		else if((*dest>='a')&&(*dest<='z'))
		{
			*dest=*dest-32;
		}
		
		src++;
		dest++;
	}
	*dest='\0';
}

int main()
{
	char arr[30];
	char brr[30];
	
	printf("Enter string:\t");
	scanf("%[^'\n']",arr);
	
	StrCpyToggle(arr,brr);
	
	printf("%s",brr);
	
	return 0;
} 