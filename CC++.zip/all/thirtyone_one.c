/*
1. Write a program which accept string from user and copy that
characters of that string into another string in reverse order.
Input : “Marvellous Python”
Output : “nohtyP suollevraM”
*/

#include<stdio.h>

void StrCpyRev(char *src, char *dest)
{	
	int  i=1;
	
	if((src == NULL) || (dest == NULL))
	{
		return;
	}
	
	while(*src!='\0')
	{
		src++;
		i++;
	}
	
	while(i>=0)
	{
		src--;
		*dest = *src;
		i--;
	}
	
	*dest = '\0';
	
	/*while(*dest!='\0')
	{
		*src = *dest;
		src++;
		dest++;
	}*/
}

int main()
{
 char arr[30]={'\0'};
 char brr[30]={'\0'}; // Empty string

 printf("Enter String:\t");
 scanf("%[^'\n']s",arr);

 StrCpyRev(arr,brr);

 printf("%s",brr); // nohtyP suollevraM

 return 0;
}