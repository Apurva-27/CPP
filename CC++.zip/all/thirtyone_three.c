/*
3. Write a program which accept string from user and copy that
characters of that string into another string by converting all small
characters into capital case.
Input : “Marvellous Python 2”
Output : “MARVELLOUS PYTHON 2”
*/

#include<stdio.h>

void StrCpyCap(char *src, char *dest)
{
	while(*src!='\0')
	{
		*dest=*src;
		if((*dest>='a')&&(*dest<='z'))
		{
			*dest = *dest - 32;
		}
		src++;
		dest++;
	}
	*dest='\0';
} 

int main()
{
	char arr[30];
	char brr[30];
	
	printf("Enter string:\t");
	scanf("%[^'\n']s",arr);
	
	StrCpyCap(arr,brr);
	
	printf("Modified string:%s",brr);
	
	return 0;
}