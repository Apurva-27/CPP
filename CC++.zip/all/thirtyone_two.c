/*
2. Write a program which accept string from user and copy that
characters of that string into another string by removing all white
spaces.
Input : “Marvel lous Pyth on”
Output : “MarvellousPython”
*/

#include<stdio.h>

void StrCpyX(char *src, char *dest)
{
	while(*src!='\0')
	{
		*dest=*src;
		if(*src!=' ')
		{
			*dest++=*src;;
		}		
		src++;
	}
	*dest='\0';
}

int main()
{
 char arr[30]="Marvel lous Pyth on";
 char brr[30]; // Empty string

 printf("Enter first string:\t");
 scanf("%[^'\n']s",arr); 
  
 StrCpyX(arr,brr);

 printf("%s",brr); // MarvellousPython

 return 0;
} 