/*
1.Write a program which checks whether 15th bit is On or OFF.
*/

#include<stdio.h>

typedef int BOOL;

#define TRUE 1
#define FALSE 0

BOOL ChkBit(int iNo)
{
	int iMask=0x00004000;
	int iResult=0;
	
	iResult = iNo & iMask;
	
	if(iResult==iMask)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}

}

int main()
{
	int iNo=0;
	BOOL bRet=FALSE;
	
	printf("Enter number\t");
	scanf("%d",&iNo);
	
	bRet=ChkBit(iNo);
	
	if(bRet==TRUE)
	{
		printf("Bit is On.");
	}
	else
	{
		printf("Bit is off.");
	}
	
	return 0;
}