/*
4. Write a program which accept string from user and check whether
it contains vowels in it or not.
Input : “marvellous”
Output : TRUE
Input : “Demo”
Output : TRUE
Input : “xyz”
Output : FALSE 
*/

#include<stdio.h>
#define TRUE 1
#define FALSE 0
typedef int Bool;

Bool ChkVowels(char str[])
{
	int i=0;
	
	if(str == NULL)
	{
		return FALSE;
	}
	
	while(str[i]!='\0')
	{
		if((str[i]=='a') ||(str[i]=='A') ||(str[i]=='e') ||(str[i]=='E') ||(str[i]=='i') ||(str[i]=='I') ||(str[i]=='o') ||(str[i]=='O') ||(str[i]=='u') ||(str[i]=='U'))
		{
			return TRUE;
		}
		else
		{
			return FALSE;
		}
		i++;
	}
}
 
int main()
{
	char Cval[30];
	Bool bRet=FALSE;
	
	printf("Enter String:");
	scanf("%[^'\n']s",Cval);
	
	bRet = ChkVowels(Cval);
	
	if(bRet == TRUE)
	{
		printf("String contain Vowels");
	}
	else
	{
		printf("String does not contain any Vowels");
	}
	
	return 0;
}