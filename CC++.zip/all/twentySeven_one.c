/*
1.Write a program which accept string from user and count number of
capital characters.
Input : “Marvellous Multi OS”
Output : 4 
*/

#include<stdio.h>

int CntCap(char Cval[])
{
    int iCnt=0, i=0;

    while(Cval[i]!='\0')
    {
        if((Cval[i] >= 'A') && (Cval[i] <='Z'))
        {
            iCnt++;
        }
        i++;
    }
    return iCnt;
}

int main()
{
    char Cvalue[30];
    int iRet=0;

    printf("Enter the string:\t");
    scanf("%[^'\n']s",Cvalue);

    iRet = CntCap(Cvalue);

    printf("Number of capital letters are:\t%d",iRet);

    return 0;
}