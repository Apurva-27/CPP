/*
3. Write a program which accept string from user and return
difference between frequency of small characters and frequency of
capital characters.
Input : “MarvellouS”
Output : 6 (8-2) 
*/

#include<stdio.h>

int Difference(char Cval[])
{
    int Cap=0, Small=0, Diff=0, i=0, j=0, k=0;

    while (Cval[i]!='\0')
    {
		if(Cval[i]>='A' && Cval[i]<='Z')
		{
			Cap = Cap+1;
		}
		else
		{
			Small = Small+1;
		}
		
		i++;
    }
	
	Diff = Small - Cap;
	return Diff;
    
}

int main()
{
    char Cval[30];
    int iRet=0;

    printf("Enter String:\t");
    scanf("%[^'\n']s",Cval);

    iRet=Difference(Cval);

    printf("Difference Between capital letter and small letter is:\t%d",iRet);

    return 0;
}