/*2. Write a program which accept string from user and count number of
small characters.
Input : “Marvellous”
Output : 9
*/

#include<stdio.h>

int CntSmall(char Cval[])
{
    int iCnt=0, i=0;

    while (Cval[i]!='\0')
    {
        if((Cval[i]>='a') && (Cval[i]<='z'))
        {
            iCnt++;
        }    
        i++;
    }
      
    return iCnt;
}

int main()
{
    char Cval[30];
    int iRet=0;

    printf("Enter String:\t");
    scanf("%[^'\n']s",Cval);

    iRet = CntSmall(Cval);

    printf("Number of small letters:\t%d",iRet);

    return 0;
}
