/*
1.Write a program which accept string from user and convert it into
lower case.
Input : “Marvellous Multi OS”
Output : marvellous multi os 
*/

#include<stdio.h>

void SmallSent(char str[])
{
	int i=0;
	
	/*for(i=0; str[i]!='\0'; i++)
	{
		str[i]=str[i]+32;
	}
*/
	while(str[i]!='\0')
	{
		if(str[i]>='A' && str[i]<='Z')
		{
			str[i]=str[i]+32;
			
		}
		printf("%c",*str);
		i++;
	}
}

int main()
{
	char Cval[30];
	char cRet='\0';
	
	printf("Enter string:\t");
	scanf("%[^'\n']s",Cval);
	
	SmallSent(Cval);
	
	printf("Small letter sentence is:\t%s",Cval);
	
	return 0;
}