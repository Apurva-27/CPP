/*
1. Accept N numbers from user and return the largest number.
Input : N : 6
Elements : 85 66 3 66 93 88
Output : 93 
*/

#include<stdio.h>
#include<stdlib.h>
#define TRUE 1
#define FALSE 0

typedef int BOOL;

BOOL Large(int *arr, int iSize)
{
    int iCnt=0, iMax=0;

    if(iSize<0)
    {
        return -1;
    }

    if(arr==NULL)
    {
        return -2;
    }
    
    iMax=arr[0];
    for(iCnt=0; iCnt<iSize; iCnt++)
    {
        if(iMax < arr[iCnt])
        {
            iMax= arr[iCnt];
        }
    }
    return iMax;
}


int main()
{
    int iCnt=0 , iSize=0 , iRet=0 ;
    int *ptr=NULL;

    printf("Enter size of array:");
    scanf("%d",&iSize);

    ptr=(int*)malloc(sizeof(int)*iSize);

    if(ptr==NULL)
    {
        return -1;
    }

    printf("Enter %d Numbers:",iSize);

    for(iCnt==0; iCnt<iSize; iCnt++)
    {
        scanf("%d",&ptr[iCnt]);
    }

    iRet=Large(ptr,iSize);

    printf("Largest number in array is :%d\t",iRet);

    free(ptr);

    return 0;
}