/*
3. Accept N numbers from user and return the difference between largest
and smallest number.
Input : N : 6
 Elements : 85 66 3 66 93 88
Output : 90 (93 -3) 
*/
#include<stdio.h>
#include<stdlib.h>

int Diff(int *arr, int iSize)
{
    int iCnt=0, iMax=0, iMin=0, iDifference=0;

    if(iSize<0)
    {
        return -1;
    }

    if(arr==NULL)
    {
        return -2;
    }
    
    iMax=arr[0];
    for(iCnt=0; iCnt<iSize; iCnt++)
    {
        if(iMax < arr[iCnt])
        {
            iMax= arr[iCnt];
        }
    }

    iMin = arr[0];
    for(iCnt=0; iCnt<iSize; iCnt++)
    {
        if(iMin > arr[iCnt])
        {
            iMin= arr[iCnt];
        }
    }

    iDifference = iMax - iMin;

    return iDifference;
}


int main()
{
    int iCnt=0 , iSize=0 , iRet=0 ;
    int *ptr=NULL;

    printf("Enter size of array:");
    scanf("%d",&iSize);

    ptr=(int*)malloc(sizeof(int)*iSize);

    if(ptr==NULL)
    {
        return -1;
    }

    printf("Enter %d Numbers:",iSize);

    for(iCnt==0; iCnt<iSize; iCnt++)
    {
        scanf("%d",&ptr[iCnt]);
    }

    iRet=Diff(ptr,iSize);

    printf("Differenc of larger and small number in array is :%d\t",iRet);

    free(ptr);

    return 0;
}