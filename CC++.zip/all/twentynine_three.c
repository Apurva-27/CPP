/*
3.Write a program which accept string from user and accept one
character. Return index of first occurrence of that character.
Input : “Marvellous Multi OS”
 M
Output : 0
Input : “Marvellous Multi OS”
 W
Output : -1
Input : “Marvellous Multi OS”
 e
Output : 4 
*/

#include<stdio.h>

int FirstOcc(char *str,char cVal)
{
	int i=0;
	
	while(*str!='\0')
	{
		if(*str == cVal)
		{
			break;
		}
		str++;
		i++;
	}
	
	if(*str == cVal)
	{
		return i;
	}
	else
	{
		return -1;
	}
}

int main()
{
	char str[40];
	char cVal='\0';
	int iRet=0;
	
	printf("Enter sting:\t");
	scanf("%[^'\n']s",str);
	
	printf("Enter character:\t");
	scanf(" %c",&cVal);
	
	iRet=FirstOcc(str,cVal);
	if(iRet == -1)
	{
		printf("Their is no such a character");
	}
	else
	{
		printf("First occurance of character found at position %d",iRet);
	}
	
	return 0;
}