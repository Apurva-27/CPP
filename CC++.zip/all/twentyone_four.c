/*
4. Accept N numbers from user and display all such elements which are
divisible by 3 and 5.
Input : N : 6
 Elements : 85 66 3 15 93 88
Output : 15 
*/

#include<stdio.h>
#include<stdlib.h>

void ChkDivFiveThree(int arr[], int iSize)
{
    int iCnt = 0, iChk = 0 ; 

    if(arr == NULL)
    {
        return;
    }
    if(iSize <= 0)
    {
        return;
    }
    printf("Numbers divisible by Five are:\t");
    for(iCnt=0; iCnt<iSize; iCnt++)
    {
        if( ((arr[iCnt] % 3)==0) && ((arr[iCnt] % 5)==0) )
        {
            printf("%d\t",arr[iCnt]);
        }
    }
}

int main()
{
    int iValue=0, iLen=0, iCnt=0;
    int *ptr=NULL;

    printf("Enter total number of array:\t");
    scanf("%d",&iValue);

    ptr=(int*)malloc(sizeof(int)*iValue);

    if(ptr == NULL)
    {
        return -1;
    }

    printf("Print %d Numbers:\t",iValue);
    for(iCnt=0; iCnt<iValue; iCnt++)
    {
        scanf("%d",&ptr[iCnt]);
    }

    ChkDivFiveThree(ptr,iValue);

    return 0;
}