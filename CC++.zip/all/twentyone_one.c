/*
1. Accept N numbers from user and return difference between summation
of even elements and summation of odd elements.
Input : N : 6
 Elements : 85 66 3 80 93 88
Output : 53 (234 - 181)
*/
#include<stdio.h>
#include<stdlib.h>
#define ERRMEMORY -1
#define ERRSIZE -2

/*int Difference(int Arr[], int iSize)
{
    int iCnt=0, iEveSum=0, iOddSum=0, iDiffEveSumOddSum= 0;

    for(iCnt=0; iCnt<iSize; iCnt++)
    {
        if((Arr[iCnt] % 2)==0)
        {
            iEveSum = iEveSum + Arr[iCnt];
        }
        else
        {
            iOddSum = iOddSum + Arr[iCnt];
        }
    }  
    //return iEveSum;
    //return iOddSum;    
    iDiffEveSumOddSum = iEveSum - iOddSum;

    return iDiffEveSumOddSum;
}
*/
int Difference(int arr[], int iSize)
{    
    int iCnt =0;
    int iEven = 0 , iOdd = 0 , iDiff = 0;
    
    if(arr == NULL)         // If the pointer is NULL means there is no memory
    {
        return ERRMEMORY;       // return -1
    }
    if(iSize <= 0)          // If the size of array is invalid
    {
        return ERRSIZE;         // return -2
    }
    
    for(iCnt = 0; iCnt < iSize; iCnt++)     // Loop to travel the array
    {
        if((arr[iCnt] % 2) == 0)        // Check whether number is even or not
        {
            iEven = iEven + arr[iCnt];                            // Increment the counter
        }
        else
        {
            iOdd = iOdd + arr[iCnt];
        } 
    }
    
    iDiff = iEven - iOdd;
    return iEven;
    //return iDiff;                                  // Return the counter
}

int main()
{
    int iSize = 0,iRet = 0,iCnt = 0,iLength=0;
    int *p = NULL;
    
    printf("Enter number of elements\t");
    scanf("%d",&iLength);
    
    p = (int *)malloc(iSize * sizeof(int));
 
    if(p == NULL)
    {
        printf("Unable to allocate memory\n");
        return -1;
    }
 
    printf("Enter %d elements:",iLength);
 
    for(iCnt = 0; iCnt<iLength; iCnt++)
    {
        //printf("Enter element :");
        scanf("%d",&p[iCnt]);
    }
    
    iRet = Difference(p, iSize);

    printf("Result is %d",iRet);
 
    free(p);
    
    return 0;
} 