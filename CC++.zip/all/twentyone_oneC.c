/*
1. Accept N numbers from user and return difference between summation
of even elements and summation of odd elements.
Input : N : 6
 Elements : 85 66 3 80 93 88
Output : 53 (234 - 181)
*/


#include<stdio.h>   // printf & scanf
#include<stdlib.h>  // for malloc

#define ERRMEMORY -1
#define ERRSIZE -2

int Difference(int arr [], int iSize) 
{
    int iCnt =0;
    int iEven = 0 , iOdd = 0 , iDiff = 0;
    
    if(arr == NULL)         
    {
        return ERRMEMORY;   
    }
    if(iSize <= 0)          
    {
        return ERRSIZE;         
    }
    
    for(iCnt = 0; iCnt < iSize; iCnt++)     
    {
        if((arr[iCnt] % 2) == 0)        
        {
            iEven = iEven + arr[iCnt];                            
        }
        else
        {
            iOdd = iOdd + arr[iCnt];
        } 
    }
    
    iDiff = iEven - iOdd;

    return iDiff;                                  
}

int main()
{
    int iValue = 0;
    int iRet = 0;
    int iCnt = 0;
    int *ptr = NULL;
    
    printf("Enter the value of N\n");
    scanf("%d",&iValue);               
    
    ptr = (int *)malloc(sizeof(int) * iValue);      
    if(ptr == NULL)     
    {
        printf("Error : Unable to allocate memory\n");
        return -1;      
    }
    
    printf("Enter the values\n");
    for(iCnt = 0; iCnt < iValue; iCnt++)
    {
        scanf("%d",&ptr[iCnt]);     
    }
    
    iRet = Difference(ptr,iValue);      
    if(iRet == ERRSIZE)                    

    iRet = Difference(ptr,iValue);      
    if(iRet == ERRSIZE)                 
    {
        printf("Error : Invalid size\n");
    }
    else if (iRet == ERRMEMORY)     
    {
        printf("Error : Invalid memory address\n");
    }
    else                            
    {
        printf("Difference of even numbers and odd numbers is : %d\t",iRet);
    }
    
    free(ptr);                      
    
    return 0;               
}