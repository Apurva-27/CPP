/*
5. Accept N numbers from user and return product of all odd elements.
Input : N : 6

 Elements : 15 66 3 70 10 88
Output : 45
Input : N : 6

 Elements : 44 66 72 70 10 88
Output : 0 
*/

#include<stdio.h>
#include<stdlib.h>

int ProductOdd(int arr[],int iVal)
{
    int iCnt=0, iProduct=1;

    for(iCnt==0; iCnt<iVal; iCnt++)
    {
        if((arr[iCnt] % 2)!=0)
        {
            iProduct = iProduct * (arr[iCnt]);
        }        
    }

    return iProduct;
}

int main()
{
    int iCnt=0, iSize=0,iNo=0,iRet=0;
    int *ptr=NULL;

    printf("Enter Size of array:\t");
    scanf("%d",&iSize);

    ptr=(int*)malloc(sizeof(int)*iSize);

    if(ptr==NULL)
    {
        return -1;
    }

    printf("Enter %d number:",iSize);

    for(iCnt=0; iCnt<iSize; iCnt++)
    {
        scanf("%d",&ptr[iCnt]);
    }

    iRet=ProductOdd(ptr,iSize);

    printf("Product of Odd numbers is %d",iRet);

    free(ptr);
    
    return 0;
}