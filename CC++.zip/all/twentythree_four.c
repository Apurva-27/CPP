/*
4. Accept N numbers from user and accept Range, Display all elements from
that range
Input : N : 6
 Start: 60

 End : 90

 Elements : 85 66 3 76 93 88
Output : 66 76 88 
*/

#include<stdio.h>
#include<stdlib.h>

void Range(int *arr,int iVal,int iStart,int iEnd)
{
    int iCnt=0;

    for (iCnt==0; iCnt<iVal; iCnt++)
    {     
        if(arr[iCnt]>=iStart && arr[iCnt]<=iEnd)
        {
            printf("%d\t",arr[iCnt]);      
        }
    }

}

int main()
{
    int iCnt=0, iStart=0, iEnd=0, iNo=0, iVal=0;
    int *ptr =NULL;

    printf("Enter number of Array\t");
    scanf("%d",&iVal);

    ptr=(int*)malloc(sizeof(int)*iVal);

    if(ptr==NULL)
    {
        return -1;
    }

    printf("Enter %d Number\t",iVal);
    for (iCnt=0 ; iCnt<iVal ; iCnt++)
    {
        scanf("%d",&ptr[iCnt]);
    }
    
    printf("Enter start number:\t");
    scanf("%d",&iStart);

    printf("Enter end number:\t");
    scanf("%d",&iEnd);

    Range(ptr,iVal,iStart,iEnd);

    free(ptr);

    return 0;
}