/*]000000
03. Accept N numbers from user and accept one another number as NO ,
return index of last occurrence of that NO.
Input : N : 6
 NO: 66
 Elements : 85 66 3 66 93 88
Output : 3
Input : N : 6
 NO: 93
 Elements : 85 66 3 66 93 88
Output : 4
Input : N : 6
 NO: 12
 Elements : 85 11 3 15 11 111
Output : -1 
*/

#include<stdio.h>
#include<stdlib.h>

int LastOccurance(int *arr,int iSize,int iNo)
{
    int iCnt=0;

    for(iCnt=iSize; iCnt>=0; iCnt--)
    {
        if(arr[iCnt]==iNo)
        {
            break;
        }
    }

    if(iCnt==-1)
    {
        return -1;
    }
    else
    {
        return iCnt;
    }
}

int main()
{
    int iCnt=0, iSize=0, iNo=0, iRet=0;
    int *ptr=NULL;
    
    printf("Enter number of Array:\t");
    scanf("%d",&iSize);

    ptr=(int*)malloc(sizeof(int)*iSize);

    if(ptr==NULL)
    {
        return -1;
    }

    printf("Enter elemets in Array:\t");

    for(iCnt=0; iCnt<iSize; iCnt++)
    {
        scanf("%d",&ptr[iCnt]);
    }

    printf("Enter number to search:\t");
    scanf("%d",&iNo);

    iRet=LastOccurance(ptr, iSize, iNo);

    if(iRet==-1)
    {
        printf("Their is no such number.");
    }    
    else
    {
        printf("Number Found at %d position",iRet);        
    }
    
    free(ptr);

    return 0;
}