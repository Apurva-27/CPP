/*
2. Accept N numbers from user and accept one another number as NO ,
return index of first occurrence of that NO.
Input : N : 6
        NO: 66
        Elements : 85 66 3 66 93 88
Output : 1
Input : N : 6
        NO: 12
        Elements : 85 11 3 15 11 111
Output : -1 
*/

#include<stdio.h>
#include<stdlib.h>

int FirstOccurance(int Arr[],int iVal, int iNo)
{
    int iCnt=0;

    for(iCnt=0; iCnt<iVal; iCnt++)
    {
        if(Arr[iCnt]==iNo)
        {
            break;
        }
    }
        if(iCnt==iVal)
        {
            return -1;
        }
        else
        {
            return iCnt;
        }
}


int main()
{
    int iCnt=0, iRet=0, iVal=0, iNo=0;
    int *ptr=NULL;

    printf("Enter number of Array:\t");
    scanf("%d",&iVal);

    ptr = (int*)malloc(sizeof(int)*(iVal));

    if(ptr == NULL)
    {
        return -1;
    }

    printf("Enter number to search:\t");
    scanf("%d",&iNo);

    printf("Enter numbers in Array:\t");
    for(iCnt=0; iCnt<iVal; iCnt++)
    {
        scanf("%d",&ptr[iCnt]);
    }

    iRet=FirstOccurance(ptr,iVal,iNo);

    if(iRet==-1)
    {
        printf("There is no such number\n");
    }
    else
    {
        printf("First occurance of number is  : %d\n",iRet);
    }

    free(ptr);

    return 0;
}