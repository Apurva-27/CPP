/*
5. Accept N numbers from user and accept one another number as NO ,
return frequency of NO form it.
Input : N : 6
 NO: 66
 Elements : 85 66 3 66 93 88
Output : 2
Input : N : 6
 NO: 12
 Elements : 85 11 3 15 11 111
Output : 0 
*/

#include<stdio.h>
#include<stdlib.h>
#define ERRMEMORY -1
#define ERRSIZE -2

int Frequency(int Arr[], int iLength, int iNo)
{
    int iCnt=0, iChk=0;

    if(Arr==NULL)
    {
        return ERRMEMORY;
    }
    if(iLength <=0)
    {
        return ERRSIZE;
    }
    if(iNo<=0)
    {
        return ERRSIZE;
    }

    for(iCnt=0; iCnt<iLength; iCnt++)
    {
        if(Arr[iCnt]==iNo)
        {
            iChk++;
        }
    }

    return iChk;
}

int main()
{
 int iSize = 0,iCnt = 0, iRet = 0, iValue = 0;
 int *p = NULL;
 
 printf("Enter number of elements\t");
 scanf("%d",&iSize);
 
 printf("Enter the number to Search");
 scanf("%d",&iValue);
 
 p = (int *)malloc(iSize * sizeof(int));
 
 if(p == NULL)
 {
    printf("Unable to allocate memory");
    return ERRMEMORY;
 }
 
 printf("Enter %d elements\t",iSize);
 
 for(iCnt = 0;iCnt<iSize; iCnt++)
 {
    scanf("%d",&p[iCnt]);
 }
 
 iRet = Frequency(p, iSize,iValue);
 printf("Count is:\t%d",iRet);
 
 free(p);
 
 return 0;
} 