/*
2. Accept N numbers from user and return difference between frequency of
even number and odd numbers.
Input : N : 7
 Elements : 85 66 3 80 93 88 90
Output : 1 (4 -3) 
*/

#include<stdio.h>
#include<stdlib.h>

#define ERRMEMORY -1
#define ERRSIZE -2

int ChkDifference(int *arr, int iSize)
{
    int iCnt=0, iEve=0, iOdd=0, iDiff=0;

    if(arr==NULL)
    {
        return ERRMEMORY;
    }
    if(iSize <=0)
    {
        return ERRSIZE;
    }

    for(iCnt=0; iCnt<iSize; iCnt++)
    {
        if((arr[iCnt] % 2)==0)
        {
            iEve++;           
        }
        else
        {
            iOdd++;
        }                 
    }
    iDiff = iEve - iOdd;
    
    return iDiff;
}

int main()
{
    int iValue=0, iLen=0, iCnt=0, iRet=0;
    int *ptr = NULL;

    printf("enter nuber of array:\t");
    scanf("%d",&iValue);

    ptr=(int*)malloc(sizeof(int)*iValue);

    if(ptr == NULL)
    {
        return ERRMEMORY;
    }

    printf("Enter numbers:\t");

    for(iCnt=0; iCnt<iValue; iCnt++)
    {
        scanf("%d",&ptr[iCnt]);
    }

    iRet=ChkDifference(ptr,iValue);

    printf("Difference in frequency of Even number and Odd number is:%d\t ",iRet);

    return 0;
}