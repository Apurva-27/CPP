#include<stdio.h>

int main()
{
	int a=0,b=0,c=0;
	
	printf("enter value of a and b");
	scanf("%d %d",&a,&b);
	
	c=a+b;
	
	printf("%d +%d= %d",a,b ,c);
}