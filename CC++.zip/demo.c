#include<stdio.h>

void Concat(char *src, char *dest)
{
	while(*dest!='\0')
	{
		dest++;
	}
	
	while(*src!='\0')
	{
		*dest = *src;
		src++;
		dest++;
	}
	*dest='\0';
}

int main()
{
	char arr[30]={'\0'};
	char brr[30]={'\0'};
	
	printf("Enter string1:\t");
	scanf("%[^'\n']s",arr);
	
	printf("Enter string2:\t");
	scanf(" %[^'\n']s",brr);
	
	Concat(arr,brr);
	
	printf("Concat:%s",brr);


	return 0;
}