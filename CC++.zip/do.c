#include<stdio.h>

int Toggle(int iNo)
{
    int iMask=0x00001F00;
    int iResult=0;

    iResult = iNo ^ iMask;

    return iResult; 
}

int main()
{
    int iNO=0 , iRet=0;

    printf("Enter Number:\t");
    scanf("%d",&iNO);

    iRet = Toggle(iNO);

    printf("Number aft toggle\t%d",iRet);

    return 0; 
}