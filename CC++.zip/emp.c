#include<stdio.h>
#include<stdlib.h>

struct Employee
{
	int Eid,Eage;
	char Eproject,Ename[40],Eadd[70],Egender;
	float Esalary;
	struct Employee *next;
};

int main()
{

return 0;
}