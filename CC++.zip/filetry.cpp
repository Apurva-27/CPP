#include <iostream>

#include <fstream>

#include <string>

using namespace std;

void printPlayer(string, int, string*, string*, string*, int**);

void printCol(int, int, string*, int**);

int main()
{

        const int HEADERS = 6;

        const int FIRST = 0;

        const int SECOND = 1;

        const int THIRD = 2;

        const int FOURTH = 3;

        const int FIFTH = 4;

        string fileName;

        ifstream sfin;

        int numPlayers;

        string *fNames, *lNames, *headers = new string[HEADERS];

        int **stats;

        string input;

        cout<<"Enter the statistics file name > ";

        cin>>fileName;

        sfin.open(fileName.c_str());

        if (!sfin)

               exit(-1);
        sfin>>numPlayers;

        fNames= new string[numPlayers];

        lNames= new string[numPlayers];

        stats= new int*[numPlayers];  
    

        for(int i=0; i<HEADERS; i++)

        sfin>>headers[i];

        for(int j=0; j<numPlayers; j++)

        {

                sfin>>fNames[j]>>lNames[j];

 

               stats[j]= new int[HEADERS-1];

               for(int k=0; k<HEADERS-1; k++)

                       sfin>>stats[j][k];

        }
        //////////GET INPUT////////////

        cout<<"HOCKEY STATS > ";

        cin>>input;

        while(input!="Q" && input!="q" && input!="QUIT" && input!="quit")

        {
               if (input==headers[0])

               {

                       string lookForLast;

                       cin>>lookForLast;

                       printPlayer(lookForLast, numPlayers, headers, fNames, lNames, stats);

               }

               else if (input==headers[1])

                       printCol(FIRST, numPlayers, lNames, stats);  

               else if (input==headers[2])

                       printCol(SECOND, numPlayers, lNames, stats);

               else if (input==headers[3])

                       printCol(THIRD, numPlayers, lNames, stats);

               else if (input==headers[4])

                       printCol(FOURTH, numPlayers, lNames, stats);

               else if (input==headers[5])

                       printCol(FIFTH, numPlayers, lNames, stats);

 

               cout<<"HOCKEY STATS > ";

               cin>>input;

        }

 

        return 0;

}
//Prints out a player's full name and his stats

void printPlayer(string name, int rows, string* top, string* first, string* last, int** stats)

{
	int HEADERS=6, FIRST=1		;
        for(int i=0; i<rows; i++)
        {
               if(name==last[i])
               {
                       for(int j=0; j<HEADERS;j++)
                       {
                               if (j==FIRST)
                               cout<<"\t";

                               cout<<"\t"<<top[j];
                       }

                       cout<<endl<<"\t"<<first[i]<<" "<<last[i];

                       for(int k=0; k<HEADERS-1; k++)

                       cout<<"\t"<<stats[i][k];

                       cout<<endl<<endl;
               }
        }
}
//Prints last name of player and value of player with highest value in col

void printCol(int colNum, int rows, string* name, int ** stats)

{
        int indexOfHighest=0;

        for (int i=0; i<rows; i++)

        {
               if (stats[i][colNum]>stats[indexOfHighest][colNum])

                       indexOfHighest=i;
        }

        cout<<"\t"<<name[indexOfHighest]<<"\t"<<stats[indexOfHighest][colNum]<<endl<<endl;
}       