/*
5. Accept on character from user and check whether that character is vowel
(a,e,i,o,u) or not.
Input : E Output : TRUE
Input : d Output : FALSE 
*/

#include<stdio.h>

typedef int BOOLEAN;
# define TRUE 1
# define FALSE 0

BOOLEAN ChkVowel (char cChar)
{
    if(cChar=='a' || cChar=='e' || cChar=='i'|| cChar=='o'|| cChar=='u')
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

int main()
{
    char cValue = '\0';
    BOOLEAN bRet = FALSE;

    printf("Enter character\n");
    scanf("%c",&cValue);
 
    bRet = ChkVowel(cValue );

    if (bRet == 1)
    {
         printf("It is Vowel\n");
    }
    else
    {
         printf("It is not Vowel\n");
    }  
 return 0;
}
