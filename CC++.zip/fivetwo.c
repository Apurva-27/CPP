#include<stdio.h>

int Multiplication(int iNo1,int iNo2,int iNo3)
{
    int iMult =1;

    if((iNo1==0)&&(iNo2==0)&&(iNo3==0))
    {
        return 0;
    }

    if(iNo1==0)
    {
        iNo1=1;
    }
    if(iNo2==0)
    {
        iNo2=1;
    }
    if(iNo3==0)
    {
        iNo3=1;
    }

    iMult = iNo1*iNo2*iNo3;

    return iMult;
}

int main()
{
    int iV1=0 ,iV2=0 ,iV3=0;
    int iRet=0;

    printf("Enter three numbers:\t");
    scanf("%d %d %d",&iV1,&iV2,&iV3);

    iRet = Multiplication(iV1,iV2,iV3);

    printf("Multiplication is:\t%d",iRet);
}