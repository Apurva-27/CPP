#include<stdio.h>


{
	
}

int main()
{
	int iNo=0,iRet=0;
	
	printf("Enter number\t");
	scanf("%d",&iNo);

	iRet=Max(iNo);
	printf("%d",iRet);
	
return 0;
}