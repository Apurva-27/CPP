#include<stdio.h>

typedef int BOOL;

#define TRUE 1
#define FALSE 0

BOOL ChkPalin(int iNo)
{
    int iDigit = 0;
    int iRev = 0;
    int iBackup=0;
    iBackup = iNo;
    
    while (iNo != 0)
    {
        iDigit =iNo %10;
        iRev = (iRev * 10)+iDigit;
        iNo = iNo / 10;
    } 
    
    if(iBackup==iRev)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
    
   
}

int main()
{
    int iValue = 0;
    BOOL bRet = FALSE;

    printf("Enter numbe:\t");
    scanf("%d0",&iValue);

    bRet = ChkPalin(iValue);

    if(bRet==TRUE)
    {
        printf("It is palindrome");
    }   
    else
    {
        printf("It is not palindrome");
    }
     
}