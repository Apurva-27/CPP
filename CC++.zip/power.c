#include<stdio.h>

int Power(int x,int y)
{
	int iResult=1;
	
	while(y!=0)
	{
		iResult= iResult*x;
		y--;
	}
	
	return iResult;
}

int main()
{
	int iNo1=0, iNo2=0, iRet=0;
	
	printf("Enter first number\t");
	scanf("%d",&iNo1);

	printf("Enter second number\t");
	scanf("%d",&iNo2);

	iRet=Power(iNo1,iNo2);
	printf("result %d",iRet);

return 0;
}