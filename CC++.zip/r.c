/*RECURSION
Display 4 times Hello
*/

#include<stdio.h>

void DisplayS()	//Sequential approach
{
	printf("\nHello");
	printf("\nHello");
	printf("\nHello");
	printf("\nHello");
}

void DisplayI() //Iterative approach
{
	int i=0;
	for(i=1;i<=4;i++)
	{
		printf("\nHello");
	}
}

void DisplayR()					//Recursive approach
{
	static int i=1;					//1
	
	if(i<=4)					//2
	{
		printf("\nHello");		//4
		i++;					//3
		
		 DisplayR();				//Recursive Call
	}
}

int main()
{
	DisplayR();
	return 0;
}
