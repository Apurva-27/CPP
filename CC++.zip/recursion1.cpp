/*RECURSION
Display 4 times Hello
*/

#include<stdio.h>

void DisplayS()	//Sequential approach
{
	printf("\Hello");
	printf("\Hello");
	printf("\Hello");
	printf("\Hello");
}

void DisplayI() //Iterative approach
{
	int i=0
	for(i=1;i<=4;i++)
	{
		printf("\Hello");
	}
}

void DisplayR()//Recursive approach
{
	
	
}

int main()
{
	DisplayS();
	DisplayI();
	
	return 0;
}
