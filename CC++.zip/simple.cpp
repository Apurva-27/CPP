#include<iostream>
using namespace std;

struct Node
{
	int data=0;
	struct Node *Next;
	
};

typedef struct Node NODE;
typedef struct Node* PNODE;

class Stack
{
	public:				//Access specifier
		PNODE Head;		//Characteristics

		Stack()			//Default construct
		{
			Head = NULL;
		}
		
		void Push(int Value)
		{
			PNODE newn =NULL;
			newn = new NODE;		//like malloc ,in C++ we use new operator 
			newn->data = Value;
			newn->Next=NULL;
			
			if(Head ==NULL)
			{
				Head = newn;
			}
			else
			{
				newn->Next = Head;
				Head = newn;
			}
		}
		
		void Pop(int iNo)
		{
			if(Head==NULL)
			{
				cout<<"Stack is empty";
				return;
			}
			else
			{
				int iNo=0;
				iNo = Head->data;
				PNODE temp = Head;
				Head = Head->Next;
				delete(temp);
			}
		}
		
		void Display()
		{
			PNODE temp=Head;
			
			while(temp!=NULL)
			{
				cout<<temp->data<<"->";
				temp = temp->Next;
			}
		}
};



int main()
{
	int Choice =1;
	int iNo=0, no=0;

	Stack obj1;

	

	while(Choice!=0)
	{
	cout<<"Enter choice\n";
	cout<<"1.Push\n2.Pop\n3.Display\n0.Exit";
	cin>>iNo;

		switch(Choice)
		{
			case 1:
					cout<<"Enter Element\t";
					cin>>iNo;
					obj1.Push(iNo);
			break;
			
			case 2:
					iNo=obj1.Pop;
					cout<<"Poped element\t"<<iNo;
			break;
			
			case 3:
					cout<<"Elements in stack\t";
					obj1.Display();
			break;
			
			case 0:
					cout<<"Thank you\n";
					exit(0);
			break;
		}
	}

return 0;
}