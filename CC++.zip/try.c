#include<stdio.h>
int main () 
{
int num,reminder=0,temp;

printf ("Enter the Number :");
scanf ("%d", &num);

int smallest=num%10; 

while (num > 0)
    {
		temp = num % 10;

		if (smallest > temp)
		{
			smallest = temp;
		}

		num = num / 10;
    }
	
printf ("The Smallest Digit is :%d \n", smallest); 
return 0;
}